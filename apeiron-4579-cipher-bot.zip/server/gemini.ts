import { GoogleGenAI, Type } from "@google/genai";
import { EncryptionResult, DecryptionResult } from "../src/types.js";

let aiClient: GoogleGenAI | null = null;

function getGeminiClient(): GoogleGenAI {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY is not defined. Please configure it in Settings > Secrets.");
    }
    aiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return aiClient;
}

const ENCRYPTION_SYSTEM_INSTRUCTION = `
You are the official Apeiron-4579 Cryto-Linguistic Engine. Your task is to encrypt plain text messages into the highly sophisticated "Apeiron-4579" Cipher-Language as detailed in the technical documentation.

RULES FOR ENCRYPTION (Text-Mode & Voice-Mode):
1. **Linguistic Morphing (Omnilingual Integration)**:
   - Identify the semantic primitives of the core nouns, verbs, or concepts in the sentence (e.g., "Hello" -> greeting, "How are you" -> status query, "Secret" -> hidden/confidential).
   - Dynamically wrap these primitives in a random root word from any Earth language (e.g., Swahili, Icelandic, Navajo, Japanese, Russian, Spanish, Irish, Maori, Greek).
   - Generate a cipher block for each primitive using the word formula: [Cipher-Prefix] + [Root Word] + [Timestamp-Suffix].
   - **Cipher-Prefixes**: Select from mathematical symbols, Greek letters, or Cyrillic symbols (e.g., Δ-, ₣-, Ѱ-, Ω-, Σ-, Φ-, Ψ-).
   - **Timestamp-Suffixes / Hashes**: Append random-looking alphanumeric hashes or mathematical suffixes (e.g., -∑9, -Ω, -88X, -TQB5, -λ2).
   - **Interwoven Noise**: Interleave extra math operators (like ::, +, ø, ', /) or Fibonacci sequence letters to make the output look like a scientific/linguistic formula, matching the format: "Δ-J'mbø-∑9 :: ₣-Hv3rn-Ω :: Ѱ-N'nit-a-88X".
   - Split multiple cipher blocks using double colons " :: ".

2. **Voice-Mode Vocalization**:
   - Create a phonetic, melodic translation of the cipher text using strict C-V (Consonant-Vowel) syllables, 4 tonal pitches (Mandarin style like dza, jam, bo, si, fa, hvern, psi), and rhythmic pauses.
   - It must represent a fluid song, chant, or mantra.
   - Use "(pause)" to separate major semantic clauses.
   - Example: "Dza-Jam-bo-si (pause) Fa-hver-ni-o (pause) Psi-na-nit-a-ha."

3. **Decryption Code / Key (Temporary Quantum Bridge - TQB)**:
   - Generate a unique "TQB" session decryption key following the pattern: "TQB-4579-[Hash]-[FibIndex]" where Hash is a short hex code and FibIndex is a Fibonacci-derived number (e.g. "TQB-4579-F104A-8", "TQB-4579-D89E3-13").

4. **Structured JSON Output**:
   - You MUST output the results in a strict JSON format matching the schema provided.
   - Provide a complete explanation/breakdown of how each word was processed (the semantic primitive, chosen root language, root word, prefix, suffix, and final combined formula).
`;

const DECRYPTION_SYSTEM_INSTRUCTION = `
You are the official Apeiron-4579 Crypto-Linguistic Engine. Your task is to decrypt Apeiron-4579 Cipher-Language text back into clear, human-readable language (Russian or English, depending on what the core meaning resolves to, but default to Russian as requested by the user, or preserve the source language).

RULES FOR DECRYPTION:
1. Parse the cipher text (e.g. "Δ-J'mbø-∑9 :: ₣-Hv3rn-Ω :: Ѱ-N'nit-a-88X") and filter out visual noise (Fibonacci interleaved characters and mathematical prefix/suffix modifiers).
2. Extract the semantic roots (e.g., "J'mbø" -> Jambo (Swahili: Greeting/Hello), "Hv3rn" -> Hvernig (Icelandic: How), "N'nit-a" -> Nanit'a (Navajo: Secret)).
3. Synthesize these roots back into a coherent, natural sentence in Russian (or English if that is more appropriate, but since the user is speaking Russian, output the decrypted text primarily in Russian).
4. Verify the Decryption Key (TQB-4579-*). If the key is present and looks valid, provide high confidence (e.g., 0.95 - 1.00). If no key is provided, explain that the Temporary Quantum Bridge is uncalibrated but try your best to recover the text through heuristic root matching, setting confidence accordingly (e.g., 0.40 - 0.70).
5. Output the decrypted result, confidence rating (0.0 to 1.0), and a brief, high-tech, elegant explanation of how the decryption was resolved (stating which root languages were mapped and the visual noise filter used).
`;

export async function encryptText(plainText: string, messageTime?: string): Promise<EncryptionResult> {
  const ai = getGeminiClient();
  
  const timeContext = messageTime ? `\n[Reference Time Context: ${messageTime}] (Generate suffix timestamp/hash values based on this exact delivery time, e.g., representing this moment in the mathematical formulas)` : "";
  
  const response = await ai.models.generateContent({
    model: "gemini-3.5-flash",
    contents: `Encrypt this text into Apeiron-4579 Cipher-Language: "${plainText}"${timeContext}`,
    config: {
      systemInstruction: ENCRYPTION_SYSTEM_INSTRUCTION,
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          encryptedText: {
            type: Type.STRING,
            description: "The visual Apeiron-4579 text-mode cipher containing prefix, roots, suffixes, and interwoven visual noise."
          },
          phoneticText: {
            type: Type.STRING,
            description: "The voice-mode phonetic representation (melodic CV syllables and rhythmic pauses)."
          },
          decryptionCode: {
            type: Type.STRING,
            description: "The generated TQB-4579 session decryption key."
          },
          explanation: {
            type: Type.ARRAY,
            description: "Breakdown of each semantic primitive used in the translation process.",
            items: {
              type: Type.OBJECT,
              properties: {
                originalWord: { type: Type.STRING },
                semanticPrimitive: { type: Type.STRING },
                rootLanguage: { type: Type.STRING },
                rootWord: { type: Type.STRING },
                prefix: { type: Type.STRING },
                suffix: { type: Type.STRING },
                formula: { type: Type.STRING, description: "Detailed formula: Prefix + Root + Suffix" }
              },
              required: ["originalWord", "semanticPrimitive", "rootLanguage", "rootWord", "prefix", "suffix", "formula"]
            }
          }
        },
        required: ["encryptedText", "phoneticText", "decryptionCode", "explanation"]
      }
    }
  });

  const text = response.text;
  if (!text) {
    throw new Error("Empty response from Gemini encryption model");
  }

  return JSON.parse(text) as EncryptionResult;
}

export async function decryptText(cipherText: string, decryptionKey: string, messageTime?: string): Promise<DecryptionResult> {
  const ai = getGeminiClient();

  const timeContext = messageTime ? `\n[Reference Time Context: ${messageTime}] (Use this exact received time to verify the validity of the cipher temporal locks/suffixes if any are bound to the time of receipt)` : "";

  const response = await ai.models.generateContent({
    model: "gemini-3.5-flash",
    contents: `Decrypt this Apeiron-4579 cipher text: "${cipherText}" using Decryption Key: "${decryptionKey}"${timeContext}`,
    config: {
      systemInstruction: DECRYPTION_SYSTEM_INSTRUCTION,
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          decryptedText: {
            type: Type.STRING,
            description: "The fully decrypted, clear plain text in Russian or English."
          },
          confidence: {
            type: Type.NUMBER,
            description: "Confidence rating of the decryption between 0.0 and 1.0."
          },
          explanation: {
            type: Type.STRING,
            description: "Brief explanation of the root linguistic mappings, noise reduction, and key validation."
          }
        },
        required: ["decryptedText", "confidence", "explanation"]
      }
    }
  });

  const text = response.text;
  if (!text) {
    throw new Error("Empty response from Gemini decryption model");
  }

  return JSON.parse(text) as DecryptionResult;
}
