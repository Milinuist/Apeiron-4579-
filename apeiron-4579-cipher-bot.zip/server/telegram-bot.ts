import { encryptText, decryptText } from "./gemini.js";
import { BotConfig, BotLog } from "../src/types.js";

function escapeHtml(text: string): string {
  if (!text) return "";
  return text
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

export class TelegramBotManager {
  private token: string = "";
  private isActive: boolean = false;
  private status: BotConfig["status"] = "offline";
  private lastError: string | undefined = undefined;
  private logs: BotLog[] = [];
  private lastOffset: number = 0;
  private pollTimeout: NodeJS.Timeout | null = null;
  private botUsername: string = "";

  constructor() {
    // Check if token is pre-configured in environment
    const envToken = process.env.TELEGRAM_BOT_TOKEN;
    if (envToken) {
      this.addLog("info", `Обнаружен Telegram Bot Token в окружении. Автозапуск...`);
      this.start(envToken).catch((err) => {
        this.addLog("error", `Ошибка автозапуска бота: ${err.message}`);
      });
    } else {
      this.addLog("info", "Бот не запущен. Ожидание конфигурации токена через веб-панель.");
    }
  }

  public getConfig(): BotConfig {
    return {
      token: this.token ? "••••••••" + this.token.slice(-6) : "",
      isActive: this.isActive,
      status: this.status,
      lastError: this.lastError,
    };
  }

  public getLogs(): BotLog[] {
    return this.logs;
  }

  public clearLogs() {
    this.logs = [];
    this.addLog("info", "Журнал логов очищен.");
  }

  private addLog(type: BotLog["type"], message: string, details?: string, chatId?: string, userHandle?: string) {
    const log: BotLog = {
      id: Math.random().toString(36).substring(2, 9),
      timestamp: new Date().toISOString(),
      type,
      message,
      details,
      chatId,
      userHandle,
    };
    this.logs.unshift(log);
    // Keep only last 200 logs
    if (this.logs.length > 200) {
      this.logs.pop();
    }
    console.log(`[TelegramBot] [${type.toUpperCase()}] ${message}`);
  }

  public async start(token: string): Promise<void> {
    if (this.isActive) {
      await this.stop();
    }

    this.token = token.trim();
    this.isActive = true;
    this.status = "connecting";
    this.lastError = undefined;
    this.addLog("info", "Подключение к Telegram API...");

    try {
      // Test the token
      const meRes = await fetch(`https://api.telegram.org/bot${this.token}/getMe`);
      if (!meRes.ok) {
        throw new Error(`Неверный токен. API ответил кодом: ${meRes.status}`);
      }
      const meData = await meRes.json();
      if (!meData.ok) {
        throw new Error(`Ошибка Telegram API: ${meData.description}`);
      }

      this.botUsername = meData.result.username;
      this.status = "online";
      this.addLog("info", `Бот @${this.botUsername} запущен и успешно авторизован!`, JSON.stringify(meData.result));

      // Start the long polling loop
      this.lastOffset = 0;
      this.poll();
    } catch (err: any) {
      this.status = "error";
      this.lastError = err.message;
      this.isActive = false;
      this.addLog("error", `Ошибка при запуске бота: ${err.message}`);
      throw err;
    }
  }

  public async stop(): Promise<void> {
    if (!this.isActive) return;

    this.isActive = false;
    this.status = "offline";
    if (this.pollTimeout) {
      clearTimeout(this.pollTimeout);
      this.pollTimeout = null;
    }
    this.addLog("info", `Бот @${this.botUsername || "Apeiron"} остановлен.`);
  }

  private async poll(): Promise<void> {
    if (!this.isActive) return;

    try {
      const url = `https://api.telegram.org/bot${this.token}/getUpdates?offset=${this.lastOffset}&timeout=20`;
      const res = await fetch(url);
      
      if (!res.ok) {
        throw new Error(`Telegram getUpdates failed with status ${res.status}`);
      }

      const data = await res.json();
      if (!data.ok) {
        throw new Error(`getUpdates returned ok: false. Description: ${data.description}`);
      }

      const updates = data.result;
      if (updates && updates.length > 0) {
        for (const update of updates) {
          this.lastOffset = Math.max(this.lastOffset, update.update_id + 1);
          await this.handleUpdate(update);
        }
      }

      // Schedule next poll immediately
      if (this.isActive) {
        this.pollTimeout = setTimeout(() => this.poll(), 100);
      }
    } catch (err: any) {
      this.addLog("error", `Ошибка опроса обновлений (getUpdates): ${err.message}`);
      // Wait a bit longer before retrying on network error to prevent tight failing loops
      if (this.isActive) {
        this.pollTimeout = setTimeout(() => this.poll(), 5000);
      }
    }
  }

  private async handleUpdate(update: any): Promise<void> {
    const message = update.message;
    if (!message || !message.text) return;

    const chatId = message.chat.id.toString();
    const text = message.text.trim();
    const userHandle = message.from.username ? `@${message.from.username}` : `${message.from.first_name} ${message.from.last_name || ""}`.trim();

    this.addLog("incoming", `Сообщение от ${userHandle}: "${text}"`, JSON.stringify(message), chatId, userHandle);

    // Command Parser
    try {
      if (text === "/start" || text === "/help" || text.toLowerCase() === "привет") {
        const replyText = 
          `👋 <b>Привет, ${escapeHtml(message.from.first_name)}!</b>\n\n` +
          `Я официальный крипто-лингвистический бот <b>Apeiron-4579</b>.\n\n` +
          `Я могу кодировать сообщения в зашифрованный, защищенный временем (Time-Lock) язык, который не подлежит расшифровке до <b>4579 года</b> без специального ключа.\n\n` +
          `🔒 <b>Инструкция по использованию:</b>\n` +
          `1. Отправь мне фразу-триггер для начала сессии:\n` +
          `<code>INITIATE: APEIRON-4579 [Sync-Lock: Active]</code>\n\n` +
          `2. <b>Шифрование</b>: Отправь любой текст на русском или английском языке, и я сгенерирую для тебя:\n` +
          `   • <b>Текст-Режим</b> (визуальный шифр)\n` +
          `   • <b>Вокал-Режим</b> (фонетическую читку для произношения)\n` +
          `   • <b>TQB-ключ</b> сессии для последующей расшифровки.\n\n` +
          `3. <b>Расшифровка</b>: Чтобы расшифровать текст обратно, отправь команду:\n` +
          `<code>/decrypt &lt;зашифрованный_текст&gt; &lt;ключ_TQB&gt;</code>\n` +
          `<i>(Пример: /decrypt Δ-J'mbø-∑9 :: ₣-Hv3rn-Ω TQB-4579-A8F2-5)</i>\n\n` +
          `💡 <i>Вы также можете просто отправить зашифрованный текст напрямую (с ключом TQB или без него), и я расшифрую его автоматически!</i>`;

        await this.sendMessage(chatId, replyText);
        return;
      }

      if (text === "INITIATE: APEIRON-4579 [Sync-Lock: Active]") {
        const replyText = 
          `🔒 <b>[Sync-Lock: Active]</b>\n\n` +
          `Временный Квантовый Мост (Temporary Quantum Bridge - TQB) стабилизирован!\n` +
          `Канал связи переведен в режим Apeiron-4579.\n\n` +
          `Отправь мне обычный текст, и я зашифрую его.`;
        await this.sendMessage(chatId, replyText);
        return;
      }

      // Check if message is a decryption command or contains typical Apeiron cipher elements (auto-decryption)
      const isDecryptCommand = text.startsWith("/decrypt");
      const isAutoDecrypt = text.includes("::") || /^[Δ₣ѰΩΣΦΨ]-/.test(text) || text.toUpperCase().includes("TQB-");

      if (isDecryptCommand || isAutoDecrypt) {
        let rawContent = text;
        if (isDecryptCommand) {
          rawContent = text.substring(8).trim();
        }

        const parts = rawContent.split(/\s+/);
        let decryptionKey = "";
        let cipherText = "";

        // Find TQB key in parts
        const tqbIndex = parts.findIndex(p => p.toUpperCase().includes("TQB-"));
        if (tqbIndex !== -1) {
          decryptionKey = parts[tqbIndex];
          parts.splice(tqbIndex, 1);
          cipherText = parts.join(" ");
        } else {
          // Check if last part is a key or part of the cipher text
          const lastPart = parts[parts.length - 1];
          const isCipherPattern = /[\u0370-\u03FF\u0400-\u04FF::øΔ₣ѰΩΣΦΨ']/.test(lastPart);
          
          if (parts.length > 1 && !isCipherPattern) {
            decryptionKey = lastPart;
            parts.splice(parts.length - 1, 1);
            cipherText = parts.join(" ");
          } else {
            cipherText = parts.join(" ");
            decryptionKey = ""; // empty key, heuristic mode
          }
        }

        if (!cipherText) {
          if (isDecryptCommand) {
            await this.sendMessage(chatId, "⚠️ <b>Пожалуйста, укажите зашифрованный текст для дешифровки.</b>\nПример: <code>/decrypt Δ-J'mbø-∑9 TQB-4579-F104A-8</code>");
          }
          return;
        }

        this.addLog("info", `Запрос на дешифровку: Текст="${cipherText}", Ключ="${decryptionKey || "Отсутствует"}"`, undefined, chatId, userHandle);
        await this.sendChatAction(chatId, "typing");

        // Use message timestamp for accurate time-lock validation matching receipt time
        const messageTime = message.date ? new Date(message.date * 1000).toLocaleString("ru-RU") : new Date().toLocaleString("ru-RU");

        const result = await decryptText(cipherText, decryptionKey, messageTime);

        const confidencePercent = Math.round(result.confidence * 100);
        const emoji = result.confidence > 0.8 ? "✅" : "⚠️";

        const replyText = 
          `🔓 <b>Apeiron-4579 — Дешифровка успешно завершена!</b>\n\n` +
          `📝 <b>Исходный текст:</b>\n` +
          `"${escapeHtml(result.decryptedText)}"\n\n` +
          `${emoji} <b>Точность расшифровки:</b> ${confidencePercent}%\n` +
          `🔬 <b>Анализ лингвистического моста:</b>\n` +
          `<i>${escapeHtml(result.explanation)}</i>`;

        await this.sendMessage(chatId, replyText);
        return;
      }

      // Normal message - encrypt it
      this.addLog("info", `Запрос на шифрование: "${text}"`, undefined, chatId, userHandle);
      await this.sendChatAction(chatId, "typing");

      // Use message timestamp for precise visual noise creation matching exact receipt time
      const messageTime = message.date ? new Date(message.date * 1000).toLocaleString("ru-RU") : new Date().toLocaleString("ru-RU");

      const result = await encryptText(text, messageTime);

      let breakdownStr = result.explanation.map(exp => 
        `• <b>"${escapeHtml(exp.originalWord)}"</b> → Смысловой примитив: <i>${escapeHtml(exp.semanticPrimitive)}</i>. Корень из языка: <i>${escapeHtml(exp.rootLanguage)}</i> (${escapeHtml(exp.rootWord)}). Формула: <code>${escapeHtml(exp.formula)}</code>`
      ).join("\n");

      const replyText = 
        `🔒 <b>Apeiron-4579 — Текст зашифрован!</b>\n\n` +
        `📝 <b>Зашифрованный текст (Text-Mode):</b>\n` +
        `<code>${escapeHtml(result.encryptedText)}</code>\n\n` +
        `🎵 <b>Фонетика (Voice-Mode):</b>\n` +
        `<i>${escapeHtml(result.phoneticText)}</i>\n\n` +
        `🔑 <b>Ключ дешифровки (TQB):</b>\n` +
        `<code>${escapeHtml(result.decryptionCode)}</code>\n\n` +
        `🔬 <b>Лингвистическая калибровка моста:</b>\n` +
        breakdownStr + `\n\n` +
        `<i>Этот шифр не может быть раскрыт вычислительными системами до 4579 года без указанного ключа TQB.</i>`;

      await this.sendMessage(chatId, replyText);
    } catch (err: any) {
      this.addLog("error", `Ошибка обработки сообщения от ${userHandle}: ${err.message}`, err.stack, chatId, userHandle);
      await this.sendMessage(chatId, `❌ <b>Критический сбой квантового моста:</b>\n\n<code>${escapeHtml(err.message)}</code>\n\nПожалуйста, убедитесь, что API-ключи настроены правильно, и повторите попытку.`);
    }
  }

  private async sendMessage(chatId: string, text: string): Promise<void> {
    try {
      const url = `https://api.telegram.org/bot${this.token}/sendMessage`;
      let res = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          chat_id: chatId,
          text: text,
          parse_mode: "HTML",
        }),
      });

      if (!res.ok) {
        const errorData = await res.json().catch(() => ({}));
        const description = errorData.description || `HTTP error ${res.status}`;

        // Fallback retry if HTML is malformed or unparseable by Telegram API
        if (description.includes("can't parse entities") || description.includes("parse")) {
          this.addLog("error", `Ошибка парсинга HTML в Telegram (${description}). Повторная отправка без HTML форматирования...`);
          
          // Basic clean string to ensure smooth plain-text presentation
          const plainText = text
            .replace(/<[^>]+>/g, "")
            .replace(/&lt;/g, "<")
            .replace(/&gt;/g, ">")
            .replace(/&amp;/g, "&");

          res = await fetch(url, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              chat_id: chatId,
              text: plainText,
            }),
          });

          if (!res.ok) {
            const finalErrorData = await res.json().catch(() => ({}));
            throw new Error(finalErrorData.description || `HTTP error ${res.status}`);
          }
        } else {
          throw new Error(description);
        }
      }

      this.addLog("outgoing", `Ответ отправлен в чат ${chatId}`, text, chatId, `@${this.botUsername}`);
    } catch (err: any) {
      this.addLog("error", `Не удалось отправить сообщение в чат ${chatId}: ${err.message}`);
    }
  }

  private async sendChatAction(chatId: string, action: string): Promise<void> {
    try {
      const url = `https://api.telegram.org/bot${this.token}/sendChatAction`;
      await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          chat_id: chatId,
          action: action,
        }),
      });
    } catch (err) {
      // Ignored (non-critical chat status effect)
    }
  }
}

// Export a single global instance for the Express server to use
export const telegramBotManager = new TelegramBotManager();
