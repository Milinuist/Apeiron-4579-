import express from "express";
import path from "path";
import dotenv from "dotenv";
import { createServer as createViteServer } from "vite";
import { encryptText, decryptText } from "./server/gemini.js";
import { telegramBotManager } from "./server/telegram-bot.js";

// Load environment variables
dotenv.config();

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Middleware
  app.use(express.json());

  // API: Health Check
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", mode: process.env.NODE_ENV || "development" });
  });

  // API: Encrypt
  app.post("/api/encrypt", async (req, res) => {
    try {
      const { text, sessionKey } = req.body;
      if (!text || typeof text !== "string") {
        return res.status(400).json({ error: "Параметр 'text' обязателен и должен быть строкой." });
      }

      const messageTime = new Date().toLocaleString("ru-RU");
      const result = await encryptText(text, messageTime);
      if (sessionKey) {
        result.decryptionCode = sessionKey;
      }
      res.json(result);
    } catch (err: any) {
      console.error("Encryption error:", err);
      res.status(500).json({ error: err.message || "Не удалось зашифровать текст." });
    }
  });

  // API: Decrypt
  app.post("/api/decrypt", async (req, res) => {
    try {
      const { cipherText, decryptionKey } = req.body;
      if (!cipherText || typeof cipherText !== "string") {
        return res.status(400).json({ error: "Параметр 'cipherText' обязателен." });
      }

      const messageTime = new Date().toLocaleString("ru-RU");
      const result = await decryptText(cipherText, decryptionKey || "", messageTime);
      res.json(result);
    } catch (err: any) {
      console.error("Decryption error:", err);
      res.status(500).json({ error: err.message || "Не удалось расшифровать текст." });
    }
  });

  // API: Get Telegram Bot Config
  app.get("/api/telegram/config", (req, res) => {
    res.json(telegramBotManager.getConfig());
  });

  // API: Update Telegram Bot Config (Start/Stop)
  app.post("/api/telegram/config", async (req, res) => {
    try {
      const { token, active } = req.body;
      
      if (active) {
        if (!token) {
          return res.status(400).json({ error: "Токен Telegram-бота обязателен для запуска." });
        }
        await telegramBotManager.start(token);
      } else {
        await telegramBotManager.stop();
      }

      res.json(telegramBotManager.getConfig());
    } catch (err: any) {
      res.status(500).json({ error: err.message || "Не удалось изменить конфигурацию бота." });
    }
  });

  // API: Get Telegram Bot Logs
  app.get("/api/telegram/logs", (req, res) => {
    res.json(telegramBotManager.getLogs());
  });

  // API: Clear Logs
  app.post("/api/telegram/logs/clear", (req, res) => {
    telegramBotManager.clearLogs();
    res.json({ success: true });
  });

  // Vite integration
  if (process.env.NODE_ENV !== "production") {
    console.log("Starting server in DEVELOPMENT mode with Vite middleware...");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    console.log("Starting server in PRODUCTION mode...");
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error("Failed to start server:", err);
});
