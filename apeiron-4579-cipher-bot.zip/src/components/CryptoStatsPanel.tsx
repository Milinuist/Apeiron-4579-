import React, { useEffect, useRef, useState } from "react";
import * as d3 from "d3";
import { Shield, BarChart3, Activity, Info, Sparkles } from "lucide-react";

interface CryptoStatsPanelProps {
  encryptedText: string;
}

interface CharFreq {
  char: string;
  count: number;
  percentage: number;
}

export default function CryptoStatsPanel({ encryptedText }: CryptoStatsPanelProps) {
  const barChartRef = useRef<SVGSVGElement | null>(null);
  const gaugeRef = useRef<SVGSVGElement | null>(null);
  const [entropy, setEntropy] = useState(0);
  const [maxPossibleEntropy, setMaxPossibleEntropy] = useState(0);
  const [charList, setCharList] = useState<CharFreq[]>([]);
  const [uniques, setUniques] = useState(0);

  // Compute character distribution and Shannon Entropy
  useEffect(() => {
    if (!encryptedText) {
      setEntropy(0);
      setMaxPossibleEntropy(0);
      setCharList([]);
      setUniques(0);
      return;
    }

    const text = encryptedText;
    const len = text.length;
    const counts: Record<string, number> = {};

    for (const char of text) {
      counts[char] = (counts[char] || 0) + 1;
    }

    const uniqueCount = Object.keys(counts).length;
    setUniques(uniqueCount);

    let calculatedEntropy = 0;
    const list: CharFreq[] = [];

    for (const [char, count] of Object.entries(counts)) {
      const p = count / len;
      calculatedEntropy -= p * Math.log2(p);
      list.push({
        char: char === " " ? "␣" : char,
        count,
        percentage: p * 100
      });
    }

    // Sort by frequency descending
    list.sort((a, b) => b.count - a.count);

    setEntropy(calculatedEntropy);
    // Max theoretical entropy for this alphabet size
    setMaxPossibleEntropy(uniqueCount > 1 ? Math.log2(uniqueCount) : 1);
    setCharList(list);
  }, [encryptedText]);

  // Render D3 Entropy Gauge
  useEffect(() => {
    if (!gaugeRef.current) return;

    const svgElement = d3.select(gaugeRef.current);
    svgElement.selectAll("*").remove();

    const width = 160;
    const height = 110;
    const margin = { top: 15, right: 15, bottom: 10, left: 15 };

    const svg = svgElement
      .attr("width", width)
      .attr("height", height)
      .append("g")
      .attr("transform", `translate(${width / 2}, ${height - margin.bottom})`);

    // Radius
    const r = Math.min(width - margin.left - margin.right, (height - margin.top - margin.bottom) * 2) / 2;

    // Scaling entropy from 0 to 8 (Standard theoretical limit for 8-bit text)
    const val = Math.min(8, Math.max(0, entropy));
    const angleScale = d3.scaleLinear()
      .domain([0, 8])
      .range([-Math.PI / 2, Math.PI / 2]);

    // Background track arc
    const backgroundArc = d3.arc<any>()
      .innerRadius(r - 14)
      .outerRadius(r)
      .startAngle(-Math.PI / 2)
      .endAngle(Math.PI / 2)
      .cornerRadius(4);

    svg.append("path")
      .attr("d", backgroundArc as any)
      .attr("fill", "#1e293b");

    // Dynamic gradient arc
    const gradientArc = d3.arc<any>()
      .innerRadius(r - 14)
      .outerRadius(r)
      .startAngle(-Math.PI / 2)
      .endAngle(angleScale(val))
      .cornerRadius(4);

    // Create Linear Gradient
    const gradientId = "entropy-gauge-grad";
    const defs = svgElement.append("defs");
    const linearGradient = defs.append("linearGradient")
      .attr("id", gradientId)
      .attr("x1", "0%")
      .attr("y1", "0%")
      .attr("x2", "100%")
      .attr("y2", "0%");

    linearGradient.append("stop")
      .attr("offset", "0%")
      .attr("stop-color", "#3b82f6"); // blue-500

    linearGradient.append("stop")
      .attr("offset", "60%")
      .attr("stop-color", "#6366f1"); // indigo-500

    linearGradient.append("stop")
      .attr("offset", "100%")
      .attr("stop-color", "#06b6d4"); // cyan-500

    svg.append("path")
      .attr("d", gradientArc as any)
      .attr("fill", `url(#${gradientId})`);

    // Needle pointer
    const needleAngle = angleScale(val);
    const needleLength = r - 16;
    const needleLine = d3.line()([
      [0, 4],
      [-2, 0],
      [0, -needleLength],
      [2, 0],
      [0, 4]
    ]);

    svg.append("path")
      .attr("d", needleLine)
      .attr("fill", "#f8fafc")
      .attr("transform", `rotate(${(needleAngle * 180) / Math.PI})`)
      .style("transition", "transform 1s ease-out");

    // Center pivot
    svg.append("circle")
      .attr("r", 5)
      .attr("fill", "#6366f1");

    // Value Text
    svg.append("text")
      .attr("text-anchor", "middle")
      .attr("y", -10)
      .attr("class", "font-mono text-base font-extrabold fill-slate-100")
      .text(entropy.toFixed(3));

    // Label
    svg.append("text")
      .attr("text-anchor", "middle")
      .attr("y", 12)
      .attr("class", "text-[9px] uppercase tracking-widest font-bold fill-slate-500")
      .text("shannon bits");

  }, [entropy]);

  // Render D3 Frequency Bar Chart
  useEffect(() => {
    if (!barChartRef.current || charList.length === 0) return;

    const svgElement = d3.select(barChartRef.current);
    svgElement.selectAll("*").remove();

    // Take top 10 unique characters for display clarity
    const displayData: CharFreq[] = charList.slice(0, 10);

    const margin = { top: 20, right: 15, bottom: 30, left: 35 };
    const width = 340;
    const height = 150;

    const svg = svgElement
      .attr("viewBox", `0 0 ${width} ${height}`)
      .attr("width", "100%")
      .attr("height", height)
      .append("g")
      .attr("transform", `translate(${margin.left}, ${margin.top})`);

    const innerWidth = width - margin.left - margin.right;
    const innerHeight = height - margin.top - margin.bottom;

    // Scales
    const xScale = d3.scaleBand()
      .domain(displayData.map(d => d.char))
      .range([0, innerWidth])
      .padding(0.25);

    const maxVal = (d3.max(displayData, d => d.percentage) as number) || 100;
    const yScale = d3.scaleLinear()
      .domain([0, Math.ceil(maxVal / 5) * 5])
      .range([innerHeight, 0]);

    // X Axis
    svg.append("g")
      .attr("transform", `translate(0, ${innerHeight})`)
      .call(d3.axisBottom(xScale).tickSize(0).tickPadding(8))
      .call(g => g.select(".domain").attr("stroke", "#334155")) // slate-700
      .call(g => g.selectAll(".tick text").attr("fill", "#94a3b8").attr("class", "font-mono font-bold text-[10px]"));

    // Y Axis
    svg.append("g")
      .call(d3.axisLeft(yScale).ticks(4).tickFormat(d => `${d}%`))
      .call(g => g.select(".domain").remove())
      .call(g => g.selectAll(".tick line").attr("stroke", "#1e293b").attr("stroke-dasharray", "2,2"))
      .call(g => g.selectAll(".tick text").attr("fill", "#64748b").attr("class", "font-mono text-[9px]"));

    // Color gradient for bars
    const barGradientId = "bar-chart-grad";
    const defs = svgElement.append("defs");
    const barGradient = defs.append("linearGradient")
      .attr("id", barGradientId)
      .attr("x1", "0%")
      .attr("y1", "100%")
      .attr("x2", "0%")
      .attr("y2", "0%");

    barGradient.append("stop")
      .attr("offset", "0%")
      .attr("stop-color", "#312e81"); // indigo-900
    barGradient.append("stop")
      .attr("offset", "100%")
      .attr("stop-color", "#6366f1"); // indigo-500

    // Render Bars
    const bars = svg.selectAll(".bar")
      .data(displayData)
      .enter()
      .append("rect")
      .attr("class", "bar cursor-pointer")
      .attr("x", d => xScale((d as CharFreq).char) || 0)
      .attr("y", innerHeight) // start from bottom for transition
      .attr("width", xScale.bandwidth())
      .attr("height", 0)
      .attr("rx", 3)
      .attr("fill", `url(#${barGradientId})`)
      .on("mouseover", function(event, d) {
        d3.select(this)
          .transition()
          .duration(150)
          .attr("fill", "#06b6d4"); // cyan-500 on hover
      })
      .on("mouseout", function(event, d) {
        d3.select(this)
          .transition()
          .duration(150)
          .attr("fill", `url(#${barGradientId})`);
      });

    // Animate bars going up
    bars.transition()
      .duration(800)
      .delay((d, i) => i * 40)
      .attr("y", d => yScale((d as CharFreq).percentage))
      .attr("height", d => innerHeight - yScale((d as CharFreq).percentage));

    // Value Labels on top of bars
    svg.selectAll(".label")
      .data(displayData)
      .enter()
      .append("text")
      .attr("class", "label font-mono text-[9px] font-bold fill-indigo-300")
      .attr("text-anchor", "middle")
      .attr("x", d => (xScale((d as CharFreq).char) || 0) + xScale.bandwidth() / 2)
      .attr("y", innerHeight)
      .text(d => (d as CharFreq).count)
      .transition()
      .duration(800)
      .delay((d, i) => i * 40)
      .attr("y", d => yScale((d as CharFreq).percentage) - 5);

  }, [charList]);

  // Determine resistance level
  const getResistanceLevel = () => {
    if (entropy === 0) return { label: "Нет данных", color: "text-slate-500", bg: "bg-slate-950/40", border: "border-slate-800" };
    if (entropy > 4.5) {
      return {
        label: "КВАНТОВАЯ (Ultra Secure)",
        color: "text-cyan-400 font-extrabold",
        bg: "bg-cyan-950/20",
        border: "border-cyan-500/30",
        desc: "Абсолютная апериодичность. Использование мульти-языковой семантики и фибоначчи-смещения устраняет частотные повторы."
      };
    }
    if (entropy > 3.0) {
      return {
        label: "ВЫСОКАЯ (Hardened)",
        color: "text-indigo-400 font-bold",
        bg: "bg-indigo-950/20",
        border: "border-indigo-500/30",
        desc: "Отличный уровень энтропии. Обычные лексические паттерны скрыты за многоуровневыми символьными подстановками."
      };
    }
    return {
      label: "СТАНДАРТНАЯ (Basic)",
      color: "text-amber-400 font-medium",
      bg: "bg-amber-950/10",
      border: "border-amber-500/20",
      desc: "Шифр короткий, частотные показатели могут обладать остаточным наклоном. Рекомендуется увеличить длину текста."
    };
  };

  const resistance = getResistanceLevel();

  if (!encryptedText) {
    return (
      <div className="bg-slate-950/40 p-5 rounded-2xl border border-slate-800/40 text-center py-10">
        <Activity className="w-8 h-8 text-slate-700 mx-auto mb-2 animate-pulse" />
        <p className="text-xs text-slate-500 italic">Ожидание квантовой трансляции текста для проведения частотного анализа...</p>
      </div>
    );
  }

  return (
    <div className="bg-slate-900/40 border border-slate-800/80 rounded-2xl p-5 space-y-5 backdrop-blur-md">
      <div className="flex items-center justify-between border-b border-slate-800/60 pb-3">
        <div className="flex items-center gap-2">
          <Activity className="w-4.5 h-4.5 text-indigo-400" />
          <h4 className="font-semibold text-slate-200 text-sm">Спектральный анализ криптостойкости</h4>
        </div>
        <span className="text-[10px] bg-indigo-500/10 text-indigo-400 px-2 py-0.5 rounded font-mono font-bold uppercase">D3 Real-Time Engine</span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-12 gap-5 items-center">
        {/* Entropy Gauge Dial (D3) */}
        <div className="md:col-span-4 flex flex-col items-center justify-center bg-slate-950/50 p-4 rounded-xl border border-slate-800/60 h-[190px]">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-2 block">Энтропия Шеннона</span>
          <div className="relative">
            <svg ref={gaugeRef} className="mx-auto overflow-visible"></svg>
          </div>
          <div className="text-[10px] text-slate-500 mt-1 flex items-center gap-1 font-mono">
            <span>Макс. в сессии:</span>
            <span className="text-slate-300 font-bold">{maxPossibleEntropy.toFixed(2)} bits</span>
          </div>
        </div>

        {/* Dynamic Frequency Bar Chart (D3) */}
        <div className="md:col-span-8 flex flex-col justify-center bg-slate-950/50 p-4 rounded-xl border border-slate-800/60 h-[190px]">
          <div className="flex justify-between items-center mb-1">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Частотный профиль (Топ-10 знаков)</span>
            <span className="text-[9px] text-slate-500 font-mono">Всего знаков: {encryptedText.length} (Уник: {uniques})</span>
          </div>
          <div className="w-full">
            <svg ref={barChartRef}></svg>
          </div>
        </div>
      </div>

      {/* Security Assessment Row */}
      <div className={`p-4 rounded-xl border ${resistance.border} ${resistance.bg} flex flex-col sm:flex-row gap-4 items-start sm:items-center`}>
        <div className="p-2 rounded-lg bg-slate-900/80 border border-slate-800 text-indigo-400 shrink-0">
          <Shield className="w-5 h-5" />
        </div>
        <div className="space-y-1">
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Криптостойкость по Apeiron-4579:</span>
            <span className={`text-xs font-mono tracking-wider ${resistance.color}`}>{resistance.label}</span>
          </div>
          {resistance.desc && (
            <p className="text-xs text-slate-400 leading-relaxed font-sans">{resistance.desc}</p>
          )}
        </div>
      </div>
    </div>
  );
}
