import React, { useState, useRef, useEffect } from "react";
import { Send, Key, Copy, Check, MessageSquare, Shield, HelpCircle, Loader2, Sparkles, Volume2 } from "lucide-react";
import { ChatMessage, EncryptionResult, DecryptionResult } from "../types.js";

export default function ChatSimulator() {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: "init-1",
      sender: "bot",
      text: "👋 Привет! Я официальный крипто-лингвистический бот Apeiron-4579. \n\nЯ кодирую сообщения в зашифрованный, защищенный временем (Time-Lock) язык, который не подлежит расшифровке вычислительными системами до 4579 года без временного квантового ключа.",
      timestamp: new Date(Date.now() - 30000).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
    },
    {
      id: "init-2",
      sender: "system",
      text: "Для запуска зашифрованной сессии введите команду:\nINITIATE: APEIRON-4579 [Sync-Lock: Active]",
      timestamp: new Date(Date.now() - 25000).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
    }
  ]);
  const [inputValue, setInputValue] = useState("");
  const [mode, setMode] = useState<"encrypt" | "decrypt">("encrypt");
  const [decryptionKey, setDecryptionKey] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [expandedMessageId, setExpandedMessageId] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isLoading]);

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputValue.trim() || isLoading) return;

    const userText = inputValue.trim();
    const messageId = Math.random().toString(36).substring(2, 9);
    const timeStr = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });

    // 1. Add User Message
    const userMsg: ChatMessage = {
      id: messageId,
      sender: "user",
      text: userText,
      timestamp: timeStr,
      isCipher: mode === "decrypt"
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputValue("");
    setIsLoading(true);

    // Check if user is sending the trigger phrase
    if (userText === "INITIATE: APEIRON-4579 [Sync-Lock: Active]") {
      setTimeout(() => {
        setMessages((prev) => [
          ...prev,
          {
            id: Math.random().toString(36).substring(2, 9),
            sender: "bot",
            text: "🔒 **[Sync-Lock: Active]**\n\nВременный Квантовый Мост (Temporary Quantum Bridge - TQB) успешно калиброван и активирован!\n\nВсе последующие сообщения будут мгновенно переводиться в зашифрованный Apeiron-4579 режим.",
            timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
          }
        ]);
        setIsLoading(false);
      }, 800);
      return;
    }

    try {
      if (mode === "encrypt") {
        // Fetch Encryption from API
        const res = await fetch("/api/encrypt", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ text: userText }),
        });

        if (!res.ok) {
          const errData = await res.json();
          throw new Error(errData.error || "Ошибка шифрования на сервере");
        }

        const data: EncryptionResult = await res.json();

        setMessages((prev) => [
          ...prev,
          {
            id: Math.random().toString(36).substring(2, 9),
            sender: "bot",
            text: `🔒 Зашифровано:\n${data.encryptedText}`,
            timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
            encryptedPayload: data
          }
        ]);
      } else {
        // Fetch Decryption from API
        const res = await fetch("/api/decrypt", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ 
            cipherText: userText, 
            decryptionKey: decryptionKey.trim() 
          }),
        });

        if (!res.ok) {
          const errData = await res.json();
          throw new Error(errData.error || "Ошибка дешифровки на сервере");
        }

        const data: DecryptionResult = await res.json();

        setMessages((prev) => [
          ...prev,
          {
            id: Math.random().toString(36).substring(2, 9),
            sender: "bot",
            text: `🔓 Расшифровано:\n${data.decryptedText}`,
            timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
            decryptedPayload: data,
            decryptionKeyUsed: decryptionKey
          }
        ]);
        // Reset key field after successful submit
        setDecryptionKey("");
      }
    } catch (err: any) {
      setMessages((prev) => [
        ...prev,
        {
          id: Math.random().toString(36).substring(2, 9),
          sender: "system",
          text: `❌ Ошибка квантового соединения: ${err.message}`,
          timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
        }
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const autofillTrigger = () => {
    setInputValue("INITIATE: APEIRON-4579 [Sync-Lock: Active]");
    setMode("encrypt");
  };

  return (
    <div className="flex flex-col h-[650px] bg-slate-900/60 rounded-2xl border border-slate-800 backdrop-blur-xl overflow-hidden shadow-2xl">
      {/* Bot Header */}
      <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-900/90">
        <div className="flex items-center gap-3">
          <div className="relative">
            <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-cyan-500 to-indigo-500 flex items-center justify-center text-white font-bold shadow-lg shadow-cyan-500/20">
              Ψ
            </div>
            <div className="absolute bottom-0 right-0 w-3 h-3 bg-emerald-500 rounded-full border-2 border-slate-950 animate-pulse"></div>
          </div>
          <div>
            <div className="font-semibold text-slate-100 flex items-center gap-2">
              Apeiron-4579 Bot
              <span className="text-[10px] bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 px-1.5 py-0.5 rounded">TQB Active</span>
            </div>
            <p className="text-xs text-slate-400">В сети (Квантовое сопряжение)</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button 
            onClick={autofillTrigger}
            className="flex items-center gap-1.5 text-xs text-slate-400 hover:text-cyan-400 bg-slate-800/50 hover:bg-slate-800 border border-slate-700/50 px-2.5 py-1.5 rounded-lg transition-all"
            title="Запустить Handshake-протокол"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Handshake</span>
          </button>
        </div>
      </div>

      {/* Messages Feed */}
      <div className="flex-1 overflow-y-auto p-6 space-y-4 scrollbar-thin scrollbar-thumb-slate-800">
        {messages.map((msg) => {
          if (msg.sender === "system") {
            return (
              <div key={msg.id} className="flex justify-center my-2">
                <div className="bg-slate-950/60 border border-slate-800/80 px-4 py-2 rounded-xl max-w-md text-center">
                  <p className="text-xs text-slate-400 font-mono flex items-center justify-center gap-1.5">
                    <Shield className="w-3.5 h-3.5 text-cyan-500" />
                    {msg.text}
                  </p>
                  {msg.text.includes("INITIATE") && (
                    <button
                      onClick={() => setInputValue("INITIATE: APEIRON-4579 [Sync-Lock: Active]")}
                      className="mt-2 text-[11px] text-cyan-400 hover:underline font-semibold"
                    >
                      Кликните для автозаполнения
                    </button>
                  )}
                </div>
              </div>
            );
          }

          const isUser = msg.sender === "user";

          return (
            <div key={msg.id} className={`flex ${isUser ? "justify-end" : "justify-start"} group`}>
              <div className={`max-w-[85%] flex flex-col ${isUser ? "items-end" : "items-start"}`}>
                <div className={`px-4 py-3 rounded-2xl ${
                  isUser 
                    ? "bg-gradient-to-br from-indigo-600 to-indigo-700 text-slate-100 rounded-tr-none shadow-md shadow-indigo-600/10" 
                    : "bg-slate-950/80 border border-slate-800/80 text-slate-200 rounded-tl-none shadow-inner"
                }`}>
                  <div className="whitespace-pre-wrap text-sm leading-relaxed">
                    {msg.text}
                  </div>

                  {/* Encrypted payload layout */}
                  {msg.encryptedPayload && (
                    <div className="mt-4 pt-3 border-t border-slate-800 space-y-3">
                      <div>
                        <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
                          <span className="flex items-center gap-1"><Volume2 className="w-3.5 h-3.5 text-amber-400" /> Фонетика (Voice-Mode):</span>
                          <button 
                            onClick={() => copyToClipboard(msg.encryptedPayload!.phoneticText, `${msg.id}-phone`)}
                            className="hover:text-slate-200 transition-colors"
                          >
                            {copiedId === `${msg.id}-phone` ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                          </button>
                        </div>
                        <div className="p-2 bg-slate-900 border border-slate-800/60 rounded-lg text-xs italic text-amber-300 font-serif">
                          {msg.encryptedPayload.phoneticText}
                        </div>
                      </div>

                      <div>
                        <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
                          <span className="flex items-center gap-1"><Key className="w-3.5 h-3.5 text-cyan-400" /> Ключ расшифровки (TQB):</span>
                          <button 
                            onClick={() => copyToClipboard(msg.encryptedPayload!.decryptionCode, `${msg.id}-key`)}
                            className="hover:text-slate-200 transition-colors"
                          >
                            {copiedId === `${msg.id}-key` ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                          </button>
                        </div>
                        <div className="p-2 bg-slate-900 border border-slate-800/60 rounded-lg text-xs font-mono text-cyan-300 select-all">
                          {msg.encryptedPayload.decryptionCode}
                        </div>
                      </div>

                      {/* Expandable linguistic analysis */}
                      <div>
                        <button
                          onClick={() => setExpandedMessageId(expandedMessageId === msg.id ? null : msg.id)}
                          className="text-[11px] text-indigo-400 hover:text-indigo-300 font-medium flex items-center gap-1 focus:outline-none"
                        >
                          {expandedMessageId === msg.id ? "Скрыть анализ моста ▲" : "Показать лингвистический анализ моста ▼"}
                        </button>

                        {expandedMessageId === msg.id && (
                          <div className="mt-2 space-y-1.5 p-2.5 bg-slate-900/80 border border-slate-800/80 rounded-lg text-xs text-slate-300">
                            <p className="font-semibold text-slate-400 border-b border-slate-800 pb-1 mb-1">Лингвистическая калибровка:</p>
                            {msg.encryptedPayload.explanation.map((exp, idx) => (
                              <div key={idx} className="space-y-0.5 border-b border-slate-800/40 pb-1.5 last:border-0 last:pb-0">
                                <div className="font-semibold text-slate-200 flex justify-between">
                                  <span>"{exp.originalWord}"</span>
                                  <span className="text-cyan-400 text-[10px] font-mono">{exp.rootLanguage}</span>
                                </div>
                                <div className="text-[11px] text-slate-400">
                                  Семантика: <span className="text-slate-300">{exp.semanticPrimitive}</span> • Корень: <span className="text-slate-300">{exp.rootWord}</span>
                                </div>
                                <div className="text-[10px] text-indigo-400 font-mono">
                                  Формула: {exp.formula}
                                </div>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  )}

                  {/* Decrypted payload layout */}
                  {msg.decryptedPayload && (
                    <div className="mt-3 pt-3 border-t border-slate-800 space-y-2">
                      <div className="flex items-center gap-2 text-xs">
                        <span className="text-slate-400">Достоверность моста TQB:</span>
                        <div className="flex-1 bg-slate-900 h-1.5 rounded-full overflow-hidden">
                          <div 
                            className={`h-full rounded-full ${
                              msg.decryptedPayload.confidence > 0.8 ? "bg-emerald-500" : "bg-amber-500"
                            }`}
                            style={{ width: `${msg.decryptedPayload.confidence * 100}%` }}
                          />
                        </div>
                        <span className={`font-mono text-[10px] ${
                          msg.decryptedPayload.confidence > 0.8 ? "text-emerald-400" : "text-amber-400"
                        }`}>
                          {Math.round(msg.decryptedPayload.confidence * 100)}%
                        </span>
                      </div>
                      <p className="text-xs text-slate-400 italic">
                        {msg.decryptedPayload.explanation}
                      </p>
                    </div>
                  )}
                </div>
                <span className="text-[10px] text-slate-500 mt-1 px-1 font-mono">{msg.timestamp}</span>
              </div>
            </div>
          );
        })}

        {isLoading && (
          <div className="flex justify-start">
            <div className="flex items-center gap-2.5 px-4 py-3 rounded-2xl bg-slate-950/40 border border-slate-800/40 text-slate-400 rounded-tl-none">
              <Loader2 className="w-4 h-4 animate-spin text-cyan-400" />
              <span className="text-xs font-mono tracking-wider">Квантовое вычисление ключа 4579...</span>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input controls panel */}
      <form onSubmit={handleSend} className="p-4 border-t border-slate-800 bg-slate-950/80 space-y-3">
        {/* Mode Selector & Aux Key Inputs */}
        <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-900/50 p-1.5 rounded-xl border border-slate-800/80">
          <div className="flex gap-1">
            <button
              type="button"
              onClick={() => setMode("encrypt")}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 ${
                mode === "encrypt" 
                  ? "bg-indigo-600 text-white shadow-md" 
                  : "text-slate-400 hover:text-slate-200 hover:bg-slate-800/50"
              }`}
            >
              <Shield className="w-3.5 h-3.5" />
              Шифрование
            </button>
            <button
              type="button"
              onClick={() => setMode("decrypt")}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 ${
                mode === "decrypt" 
                  ? "bg-cyan-600 text-white shadow-md" 
                  : "text-slate-400 hover:text-slate-200 hover:bg-slate-800/50"
              }`}
            >
              <Key className="w-3.5 h-3.5" />
              Дешифровка
            </button>
          </div>

          {mode === "decrypt" && (
            <div className="flex-1 max-w-xs flex items-center gap-1.5 bg-slate-950 border border-slate-800 px-2.5 py-1 rounded-lg">
              <Key className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
              <input
                type="text"
                placeholder="Ключ расшифровки (TQB-4579-...)"
                value={decryptionKey}
                onChange={(e) => setDecryptionKey(e.target.value)}
                className="bg-transparent text-xs text-slate-200 focus:outline-none w-full font-mono placeholder:text-slate-600 placeholder:font-sans"
                required
              />
            </div>
          )}
        </div>

        {/* Text Input Row */}
        <div className="flex gap-2">
          <input
            type="text"
            placeholder={
              mode === "encrypt" 
                ? "Введите обычный текст на русском/английском..." 
                : "Вставьте зашифрованный текст Apeiron-4579..."
            }
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            className="flex-1 bg-slate-900 text-slate-100 border border-slate-800 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 rounded-xl px-4 py-3 text-sm focus:outline-none transition-all placeholder:text-slate-500"
            required
            disabled={isLoading}
          />
          <button
            type="submit"
            disabled={isLoading || !inputValue.trim() || (mode === "decrypt" && !decryptionKey.trim())}
            className={`px-4 rounded-xl flex items-center justify-center transition-all ${
              isLoading || !inputValue.trim() || (mode === "decrypt" && !decryptionKey.trim())
                ? "bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700/30"
                : mode === "encrypt"
                  ? "bg-indigo-600 hover:bg-indigo-500 text-white shadow-lg shadow-indigo-600/20 hover:scale-[1.02]"
                  : "bg-cyan-600 hover:bg-cyan-500 text-white shadow-lg shadow-cyan-600/20 hover:scale-[1.02]"
            }`}
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
      </form>
    </div>
  );
}
