import React, { useState, useEffect } from "react";
import { Play, Square, RefreshCw, Terminal, Eye, EyeOff, Loader2, HelpCircle, Check, Trash2, AlertCircle, ExternalLink, Users, Server, Copy, User } from "lucide-react";
import { BotConfig, BotLog } from "../types.js";

export default function TelegramConfig() {
  const [config, setConfig] = useState<BotConfig | null>(null);
  const [tokenInput, setTokenInput] = useState("");
  const [showToken, setShowToken] = useState(false);
  const [logs, setLogs] = useState<BotLog[]>([]);
  const [loading, setLoading] = useState(false);
  const [logsLoading, setLogsLoading] = useState(false);
  const [error, setError] = useState("");
  const [copiedLink, setCopiedLink] = useState(false);

  // States for logging tabs and filtering
  const [activeLogTab, setActiveLogTab] = useState<"system" | "users">("system");
  const [selectedUserChatId, setSelectedUserChatId] = useState<string | null>(null);

  const handleCopyLink = () => {
    const link = window.location.origin;
    navigator.clipboard.writeText(link);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  // Fetch config & logs on mount
  useEffect(() => {
    fetchConfig();
    fetchLogs();

    // Auto-poll logs and config status every 3 seconds while active
    const interval = setInterval(() => {
      fetchLogs();
      fetchStatusOnly();
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  const fetchConfig = async () => {
    try {
      const res = await fetch("/api/telegram/config");
      const data: BotConfig = await res.json();
      setConfig(data);
      if (data.token && data.token !== "••••••••••••") {
        setTokenInput(data.token);
      }
    } catch (err) {
      console.error("Failed to fetch bot config:", err);
    }
  };

  const fetchStatusOnly = async () => {
    try {
      const res = await fetch("/api/telegram/config");
      const data: BotConfig = await res.json();
      setConfig(data);
    } catch (err) {
      // Slitently catch on polling
    }
  };

  const fetchLogs = async () => {
    try {
      setLogsLoading(true);
      const res = await fetch("/api/telegram/logs");
      const data: BotLog[] = await res.json();
      setLogs(data);
    } catch (err) {
      console.error("Failed to fetch logs:", err);
    } finally {
      setLogsLoading(false);
    }
  };

  const handleToggleBot = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!config) return;

    setLoading(true);
    setError("");

    const targetActive = !config.isActive;

    try {
      const res = await fetch("/api/telegram/config", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          token: targetActive ? tokenInput.trim() : "",
          active: targetActive
        }),
      });

      if (!res.ok) {
        const errData = await res.json();
        throw new Error(errData.error || "Ошибка конфигурации бота на сервере");
      }

      const updatedConfig: BotConfig = await res.json();
      setConfig(updatedConfig);
      fetchLogs();
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleClearLogs = async () => {
    try {
      const res = await fetch("/api/telegram/logs/clear", { method: "POST" });
      if (res.ok) {
        setLogs([]);
      }
    } catch (err) {
      console.error("Failed to clear logs:", err);
    }
  };

  const statusBadge = () => {
    if (!config) return null;
    switch (config.status) {
      case "online":
        return (
          <span className="flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 animate-pulse">
            <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
            ОНЛАЙН (Запущен)
          </span>
        );
      case "connecting":
        return (
          <span className="flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-cyan-500/10 text-cyan-400 border border-cyan-500/30">
            <Loader2 className="w-3.5 h-3.5 animate-spin" />
            ПОДКЛЮЧЕНИЕ...
          </span>
        );
      case "error":
        return (
          <span className="flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-red-500/10 text-red-400 border border-red-500/30">
            <AlertCircle className="w-3.5 h-3.5" />
            ОШИБКА
          </span>
        );
      case "offline":
      default:
        return (
          <span className="flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-slate-800 text-slate-400 border border-slate-700">
            <span className="w-2 h-2 rounded-full bg-slate-500"></span>
            ВЫКЛЮЧЕН
          </span>
        );
    }
  };

  return (
    <div className="space-y-8">
      {/* Configuration Card */}
      <div className="bg-slate-900/60 p-6 rounded-2xl border border-slate-800 backdrop-blur-xl shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-5 mb-6">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400">
              <Terminal className="w-4.5 h-4.5" />
            </div>
            <div>
              <h3 className="font-semibold text-slate-100 text-base">Подключение Живого Telegram Бота</h3>
              <p className="text-xs text-slate-400">Запустите настоящий шифровальный сервер в облаке</p>
            </div>
          </div>
          <div>{statusBadge()}</div>
        </div>

        {config && config.status === "error" && config.lastError && (
          <div className="mb-6 p-4 bg-red-500/10 border border-red-500/20 rounded-xl flex gap-3 text-sm text-red-400 leading-relaxed font-mono">
            <AlertCircle className="w-5 h-5 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold">Критический сбой инициализации:</p>
              <p className="text-xs text-red-400/90 mt-1">{config.lastError}</p>
            </div>
          </div>
        )}

        <form onSubmit={handleToggleBot} className="space-y-5">
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider">Telegram Bot Token</label>
              <a 
                href="https://t.me/BotFather" 
                target="_blank" 
                rel="noreferrer"
                className="text-xs text-indigo-400 hover:text-indigo-300 flex items-center gap-1 font-medium"
              >
                Создать бота в @BotFather
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>

            <div className="flex gap-2">
              <div className="flex-1 bg-slate-950 border border-slate-800 focus-within:border-indigo-500 rounded-xl px-3 py-2.5 flex items-center gap-3 transition-all">
                <Terminal className="w-5 h-5 text-slate-500 shrink-0" />
                <input
                  type={showToken ? "text" : "password"}
                  placeholder="Вставьте токен (например, 123456789:ABCdefGhIJKlmNoPQRsTUVwxyZ)"
                  value={tokenInput}
                  onChange={(e) => setTokenInput(e.target.value)}
                  className="bg-transparent text-sm text-slate-200 focus:outline-none w-full font-mono placeholder:text-slate-700"
                  disabled={config?.isActive || loading}
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowToken(!showToken)}
                  className="text-slate-500 hover:text-slate-300 transition-colors"
                >
                  {showToken ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>

              <button
                type="submit"
                disabled={loading || (!tokenInput.trim() && !config?.isActive)}
                className={`px-6 rounded-xl font-semibold transition-all flex items-center gap-2 ${
                  config?.isActive
                    ? "bg-red-600 hover:bg-red-500 text-white shadow-lg shadow-red-600/10"
                    : "bg-indigo-600 hover:bg-indigo-500 text-white shadow-lg shadow-indigo-600/10"
                } disabled:bg-slate-800 disabled:text-slate-500 disabled:cursor-not-allowed`}
              >
                {loading ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : config?.isActive ? (
                  <>
                    <Square className="w-4 h-4" />
                    Остановить
                  </>
                ) : (
                  <>
                    <Play className="w-4 h-4" />
                    Запустить
                  </>
                )}
              </button>
            </div>
          </div>
        </form>

        {/* Quick Instructions list */}
        <div className="mt-6 pt-5 border-t border-slate-800/60 grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
          <div className="bg-slate-950/40 p-3.5 rounded-xl border border-slate-800/40">
            <h4 className="font-bold text-slate-200 mb-1">1. Инициализация</h4>
            <p className="text-slate-400 leading-relaxed">
              Откройте Telegram, найдите бота <span className="text-slate-300 font-bold">@BotFather</span> и отправьте команду <span className="font-mono text-indigo-400">/newbot</span>.
            </p>
          </div>
          <div className="bg-slate-950/40 p-3.5 rounded-xl border border-slate-800/40">
            <h4 className="font-bold text-slate-200 mb-1">2. Получение Токена</h4>
            <p className="text-slate-400 leading-relaxed">
              Введите имя и юзернейм для нового бота. @BotFather сгенерирует буквенно-цифровой Token. Скопируйте его.
            </p>
          </div>
          <div className="bg-slate-950/40 p-3.5 rounded-xl border border-slate-800/40">
            <h4 className="font-bold text-slate-200 mb-1">3. Старт шифрования</h4>
            <p className="text-slate-400 leading-relaxed">
              Вставьте токен выше, нажмите «Запустить». Теперь любой пользователь в Telegram сможет писать вашему боту!
            </p>
          </div>
        </div>
      </div>

      {/* Remote Control Panel */}
      <div className="bg-gradient-to-br from-slate-900 via-[#0b1329] to-slate-900 p-6 rounded-2xl border border-indigo-500/15 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-500/5 rounded-full blur-2xl pointer-events-none"></div>
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <span className="text-[10px] bg-indigo-500/10 text-indigo-300 border border-indigo-500/20 px-2 py-0.5 rounded-full font-mono font-bold uppercase tracking-wider">
              Дистанционное управление
            </span>
            <h3 className="text-base font-bold text-slate-100 flex items-center gap-1.5">
              Внешняя панель контроля ИИ
            </h3>
            <p className="text-xs text-slate-400 max-w-xl leading-relaxed">
              Вы можете управлять ботом, просматривать изолированные логи каждого пользователя и кодировать/декодировать сообщения с любого устройства. Перейдите по ссылке ниже:
            </p>
          </div>
          <button
            type="button"
            onClick={handleCopyLink}
            className="flex items-center gap-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 active:scale-95 px-4.5 py-2.5 rounded-xl transition-all shadow-lg shadow-indigo-600/20 shrink-0 self-stretch sm:self-auto justify-center"
          >
            {copiedLink ? (
              <>
                <Check className="w-4 h-4 text-emerald-300" />
                Скопировано!
              </>
            ) : (
              <>
                <Copy className="w-4 h-4" />
                Скопировать адрес управления
              </>
            )}
          </button>
        </div>

        <div className="mt-4 flex items-center gap-3 bg-slate-950 border border-slate-850 px-4 py-3 rounded-xl">
          <ExternalLink className="w-4 h-4 text-slate-500 shrink-0" />
          <span className="font-mono text-xs text-indigo-300 font-bold break-all select-all flex-1">
            {typeof window !== "undefined" ? window.location.origin : "https://ais-dev-h2tf7glmxzpjwv3ttvi7mz-169537240765.europe-west2.run.app"}
          </span>
          <a
            href={typeof window !== "undefined" ? window.location.origin : "#"}
            target="_blank"
            rel="noreferrer"
            className="text-xs text-cyan-400 hover:text-cyan-300 flex items-center gap-1 font-semibold"
          >
            Открыть <ExternalLink className="w-3.5 h-3.5" />
          </a>
        </div>
      </div>

      {/* Terminal Logging Card with System vs User Splits */}
      <div className="bg-slate-900/60 p-6 rounded-2xl border border-slate-800 backdrop-blur-xl shadow-xl flex flex-col min-h-[550px]">
        {/* Header of terminal */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4 mb-4">
          <div className="flex items-center gap-2">
            <Terminal className="w-4.5 h-4.5 text-cyan-400" />
            <h3 className="font-semibold text-slate-100 text-sm">Журнал Квантового Канала (Live Console)</h3>
          </div>

          {/* Tab Selector inside console */}
          <div className="flex items-center bg-slate-950 p-1 rounded-xl border border-slate-850 self-start sm:self-auto">
            <button
              type="button"
              onClick={() => {
                setActiveLogTab("system");
                setSelectedUserChatId(null);
              }}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 ${
                activeLogTab === "system"
                  ? "bg-slate-800 text-indigo-300"
                  : "text-slate-400 hover:text-slate-200"
              }`}
            >
              <Server className="w-3.5 h-3.5" />
              Серверные / Системные
            </button>
            <button
              type="button"
              onClick={() => setActiveLogTab("users")}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 ${
                activeLogTab === "users"
                  ? "bg-slate-800 text-cyan-300"
                  : "text-slate-400 hover:text-slate-200"
              }`}
            >
              <Users className="w-3.5 h-3.5" />
              Пользовательские
            </button>
          </div>

          <div className="flex items-center gap-2 self-end sm:self-auto">
            <button
              type="button"
              onClick={fetchLogs}
              className="p-1.5 hover:bg-slate-800 rounded-lg text-slate-400 hover:text-slate-200 transition-colors border border-slate-800"
              title="Обновить логи"
              disabled={logsLoading}
            >
              <RefreshCw className={`w-3.5 h-3.5 ${logsLoading ? "animate-spin text-cyan-400" : ""}`} />
            </button>
            <button
              type="button"
              onClick={handleClearLogs}
              className="p-1.5 hover:bg-red-950/30 hover:border-red-500/20 rounded-lg text-slate-500 hover:text-red-400 border border-slate-800 transition-colors"
              title="Очистить терминал"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Compute statistics and splits dynamically */}
        {(() => {
          const systemLogs = logs.filter(log => !log.chatId);
          const userLogs = logs.filter(log => log.chatId);

          const uniqueUsersMap = new Map<string, { userHandle: string; chatId: string; lastSeen: string; count: number }>();
          for (const log of logs) {
            if (log.chatId) {
              const existing = uniqueUsersMap.get(log.chatId);
              const userHandle = log.userHandle || `Chat ${log.chatId}`;
              if (!existing) {
                uniqueUsersMap.set(log.chatId, {
                  userHandle,
                  chatId: log.chatId,
                  lastSeen: log.timestamp,
                  count: 1
                });
              } else {
                existing.count += 1;
                if (new Date(log.timestamp) > new Date(existing.lastSeen)) {
                  existing.lastSeen = log.timestamp;
                }
              }
            }
          }
          const uniqueUsers = Array.from(uniqueUsersMap.values());

          let logsToRender: BotLog[] = [];
          if (activeLogTab === "system") {
            logsToRender = systemLogs;
          } else {
            if (selectedUserChatId) {
              logsToRender = userLogs.filter(log => log.chatId === selectedUserChatId);
            } else {
              logsToRender = userLogs;
            }
          }

          const renderConsoleList = (items: BotLog[]) => {
            if (items.length === 0) {
              return (
                <p className="text-slate-600 italic text-center py-20">
                  {activeLogTab === "system"
                    ? "Журнал системы чист. Сервер работает в штатном режиме."
                    : "Пользовательские логи отсутствуют. Ожидание активности в Telegram..."}
                </p>
              );
            }

            return items.map((log) => {
              const dateStr = new Date(log.timestamp).toLocaleTimeString();
              let typeBadge = "";
              let colorClasses = "text-slate-400";
              
              if (log.type === "incoming") {
                typeBadge = "[IN]";
                colorClasses = "text-emerald-400";
              } else if (log.type === "outgoing") {
                typeBadge = "[OUT]";
                colorClasses = "text-sky-400";
              } else if (log.type === "error") {
                typeBadge = "[ERR]";
                colorClasses = "text-red-400 font-bold bg-red-950/20 px-1 py-0.5 rounded";
              } else {
                typeBadge = "[SYS]";
                colorClasses = "text-indigo-400";
              }

              return (
                <div key={log.id} className="border-b border-slate-900/65 pb-2 last:border-0 last:pb-0 font-mono text-xs">
                  <div className="flex items-start gap-2">
                    <span className="text-slate-600 shrink-0">{dateStr}</span>
                    <span className={`${colorClasses} shrink-0 font-bold`}>{typeBadge}</span>
                    <div className="flex-1 leading-relaxed">
                      <span className="text-slate-300">{log.message}</span>
                      {log.userHandle && (
                        <span className="text-[10px] text-slate-500 ml-1.5 border border-slate-800/40 px-1 rounded-md bg-slate-900/30">
                          {log.userHandle}
                        </span>
                      )}
                      {log.details && (
                        <pre className="mt-1 text-[10px] text-slate-500 bg-slate-950/60 p-2 rounded border border-slate-900 overflow-x-auto whitespace-pre-wrap">
                          {log.details}
                        </pre>
                      )}
                    </div>
                  </div>
                </div>
              );
            });
          };

          return activeLogTab === "system" ? (
            <div className="flex-1 bg-slate-950/90 rounded-xl p-4 border border-slate-900 overflow-y-auto space-y-2.5 scrollbar-thin scrollbar-thumb-slate-900 h-[400px]">
              {renderConsoleList(logsToRender)}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 flex-1 min-h-[400px]">
              {/* Left sidebar with unique users */}
              <div className="md:col-span-1 bg-slate-950/70 border border-slate-850 rounded-xl p-3 flex flex-col space-y-2 overflow-y-auto max-h-[200px] md:max-h-[420px] scrollbar-thin scrollbar-thumb-slate-900">
                <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider px-2 block mb-1">
                  Активные пользователи ({uniqueUsers.length})
                </span>
                
                <button
                  type="button"
                  onClick={() => setSelectedUserChatId(null)}
                  className={`w-full text-left p-2.5 rounded-lg text-xs font-semibold transition-all flex items-center justify-between ${
                    !selectedUserChatId 
                      ? "bg-indigo-600/15 text-indigo-300 border border-indigo-500/30" 
                      : "text-slate-400 hover:text-slate-200 hover:bg-slate-900/40"
                  }`}
                >
                  <span className="flex items-center gap-1.5">
                    <Users className="w-3.5 h-3.5" />
                    Все пользователи
                  </span>
                  <span className="text-[10px] bg-slate-900 text-slate-300 px-1.5 py-0.5 rounded-md font-bold">
                    {userLogs.length}
                  </span>
                </button>

                {uniqueUsers.map((u) => (
                  <button
                    key={u.chatId}
                    type="button"
                    onClick={() => setSelectedUserChatId(u.chatId)}
                    className={`w-full text-left p-2.5 rounded-lg text-xs transition-all flex flex-col space-y-1.5 border ${
                      selectedUserChatId === u.chatId
                        ? "bg-cyan-600/10 text-cyan-300 border-cyan-500/30"
                        : "text-slate-400 hover:text-slate-200 hover:bg-slate-900/40 border-transparent"
                    }`}
                  >
                    <div className="flex items-center justify-between font-semibold">
                      <span className="truncate flex items-center gap-1.5 max-w-[130px]">
                        <User className="w-3.5 h-3.5 text-slate-400" />
                        {u.userHandle}
                      </span>
                      <span className={`text-[10px] px-1.5 py-0.5 rounded-md ${
                        selectedUserChatId === u.chatId ? "bg-cyan-950 text-cyan-300" : "bg-slate-900 text-slate-500"
                      } font-bold`}>
                        {u.count}
                      </span>
                    </div>
                    <div className="flex justify-between items-center text-[9px] text-slate-500 font-mono">
                      <span>ID: {u.chatId}</span>
                      <span>{new Date(u.lastSeen).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</span>
                    </div>
                  </button>
                ))}
              </div>

              {/* Right panel with actual logs filtered for selected user */}
              <div className="md:col-span-3 flex flex-col bg-slate-950/90 rounded-xl p-4 border border-slate-900 overflow-y-auto space-y-2.5 h-[350px] md:h-[420px] scrollbar-thin scrollbar-thumb-slate-900">
                {selectedUserChatId && (
                  <div className="flex items-center justify-between bg-slate-900/40 border border-slate-850 px-3 py-1.5 rounded-lg text-xs mb-1">
                    <span className="text-slate-400">
                      Показаны логи пользователя:{" "}
                      <strong className="text-cyan-400 font-bold">
                        {uniqueUsers.find((u) => u.chatId === selectedUserChatId)?.userHandle || selectedUserChatId}
                      </strong>
                    </span>
                    <button
                      type="button"
                      onClick={() => setSelectedUserChatId(null)}
                      className="text-slate-500 hover:text-slate-300 transition-colors underline"
                    >
                      Сбросить фильтр
                    </button>
                  </div>
                )}
                {renderConsoleList(logsToRender)}
              </div>
            </div>
          );
        })()}
      </div>
    </div>
  );
}
