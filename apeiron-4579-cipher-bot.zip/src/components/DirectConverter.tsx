import React, { useState, useEffect } from "react";
import { Shield, Key, Copy, Check, ArrowRightLeft, Volume2, HelpCircle, Loader2, RefreshCw } from "lucide-react";
import { EncryptionResult, DecryptionResult } from "../types.js";
import CryptoStatsPanel from "./CryptoStatsPanel.tsx";

export default function DirectConverter() {
  // Encrypt State
  const [plainInput, setPlainInput] = useState("");
  const [encryptOutput, setEncryptOutput] = useState<EncryptionResult | null>(null);
  const [encryptLoading, setEncryptLoading] = useState(false);
  const [encryptError, setEncryptError] = useState("");
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  // Auto-generated session key & countdown timer
  const [sessionKey, setSessionKey] = useState<string | null>(null);
  const [timeLeft, setTimeLeft] = useState(0);

  // Decrypt State
  const [cipherInput, setCipherInput] = useState("");
  const [decryptionKey, setDecryptionKey] = useState("");
  const [decryptOutput, setDecryptOutput] = useState<DecryptionResult | null>(null);
  const [decryptLoading, setDecryptLoading] = useState(false);
  const [decryptError, setDecryptError] = useState("");

  // Manage countdown timer for session key
  useEffect(() => {
    if (!sessionKey || timeLeft <= 0) return;
    const interval = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          setSessionKey(null); // Clear key on expiration
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [sessionKey, timeLeft]);

  const handleGenerateSessionKey = () => {
    const hex = Math.floor(Math.random() * 65536).toString(16).toUpperCase().padStart(4, "0");
    const fibs = [1, 2, 3, 5, 8, 13, 21, 34, 55, 89];
    const fib = fibs[Math.floor(Math.random() * fibs.length)];
    const key = `TQB-4579-${hex}-${fib}`;
    setSessionKey(key);
    setTimeLeft(120); // 2 minutes
  };

  const formatTimeLeft = () => {
    const m = Math.floor(timeLeft / 60);
    const s = timeLeft % 60;
    return `${m}:${s.toString().padStart(2, "0")}`;
  };

  const injectKeyToDecrypter = () => {
    if (sessionKey) {
      setDecryptionKey(sessionKey);
    }
  };

  const triggerCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(id);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const handleEncrypt = async () => {
    if (!plainInput.trim() || encryptLoading) return;

    setEncryptLoading(true);
    setEncryptError("");
    setEncryptOutput(null);

    try {
      const res = await fetch("/api/encrypt", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ 
          text: plainInput.trim(),
          sessionKey: sessionKey || undefined
        }),
      });

      if (!res.ok) {
        const errData = await res.json();
        throw new Error(errData.error || "Ошибка шифрования на сервере");
      }

      const data = await res.json();
      setEncryptOutput(data);
    } catch (err: any) {
      setEncryptError(err.message);
    } finally {
      setEncryptLoading(false);
    }
  };

  const handleDecrypt = async () => {
    if (!cipherInput.trim() || decryptLoading) return;

    setDecryptLoading(true);
    setDecryptError("");
    setDecryptOutput(null);

    try {
      const res = await fetch("/api/decrypt", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ 
          cipherText: cipherInput.trim(),
          decryptionKey: decryptionKey.trim()
        }),
      });

      if (!res.ok) {
        const errData = await res.json();
        throw new Error(errData.error || "Ошибка дешифровки на сервере");
      }

      const data = await res.json();
      setDecryptOutput(data);
    } catch (err: any) {
      setDecryptError(err.message);
    } finally {
      setDecryptLoading(false);
    }
  };

  const clearEncrypt = () => {
    setPlainInput("");
    setEncryptOutput(null);
    setEncryptError("");
  };

  const clearDecrypt = () => {
    setCipherInput("");
    setDecryptionKey("");
    setDecryptOutput(null);
    setDecryptError("");
  };

  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
      {/* Encryption Module */}
      <div className="bg-slate-900/60 p-6 rounded-2xl border border-slate-800 backdrop-blur-xl flex flex-col shadow-xl">
        <div className="flex items-center gap-2 mb-4">
          <div className="w-8 h-8 rounded-lg bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400">
            <Shield className="w-4 h-4" />
          </div>
          <div>
            <h3 className="font-semibold text-slate-100 text-base">Квантовое шифрование (Apeiron-4579)</h3>
            <p className="text-xs text-slate-400">Перевод открытого текста в зашифрованный shell-код</p>
          </div>
        </div>

        <div className="space-y-4 flex-1 flex flex-col">
          {/* Автоматическая генерация сессионного ключа */}
          <div className="bg-slate-950/40 border border-slate-800 p-4 rounded-xl space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                <Key className="w-3.5 h-3.5 text-indigo-400" />
                Сессионный ключ шифрования
              </span>
              <button
                type="button"
                onClick={handleGenerateSessionKey}
                className="text-[11px] bg-indigo-600/10 hover:bg-indigo-600/20 text-indigo-400 hover:text-indigo-300 border border-indigo-500/20 px-2.5 py-1 rounded-lg font-semibold transition-all flex items-center gap-1"
              >
                <RefreshCw className="w-3 h-3" /> Сгенерировать
              </button>
            </div>

            {sessionKey ? (
              <div className="space-y-2">
                <div className="flex items-center justify-between bg-slate-950 border border-slate-850 rounded-xl px-3 py-2">
                  <span className="font-mono text-sm text-cyan-300 font-bold select-all">{sessionKey}</span>
                  <div className="flex items-center gap-1.5 text-xs text-slate-400">
                    <span className="w-1.5 h-1.5 rounded-full bg-indigo-500 animate-ping"></span>
                    <span className="font-mono text-indigo-300 font-semibold">{formatTimeLeft()}</span>
                  </div>
                </div>

                {/* Шкала таймера */}
                <div className="w-full bg-slate-900 h-1 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-indigo-500 transition-all duration-1000"
                    style={{ width: `${(timeLeft / 120) * 100}%` }}
                  />
                </div>

                <div className="flex justify-between items-center text-[10px] text-slate-500">
                  <span>Применится автоматически при шифровании</span>
                  <button
                    type="button"
                    onClick={injectKeyToDecrypter}
                    className="text-cyan-400 hover:text-cyan-300 hover:underline transition-colors"
                  >
                    Передать в дешифратор
                  </button>
                </div>
              </div>
            ) : (
              <p className="text-[11px] text-slate-500 italic text-center py-2 bg-slate-950/20 rounded-lg">
                Ключ будет сгенерирован Gemini при шифровании, либо создайте временный сессионный ключ выше.
              </p>
            )}
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-400 mb-1.5 uppercase tracking-wider">Исходный текст</label>
            <textarea
              placeholder="Введите текст для шифрования..."
              value={plainInput}
              onChange={(e) => setPlainInput(e.target.value)}
              className="w-full h-32 bg-slate-950 border border-slate-800 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 rounded-xl p-3 text-sm focus:outline-none text-slate-200 placeholder:text-slate-600 transition-all resize-none"
              disabled={encryptLoading}
            />
          </div>

          <div className="flex gap-2">
            <button
              onClick={handleEncrypt}
              disabled={encryptLoading || !plainInput.trim()}
              className="flex-1 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold py-2.5 rounded-xl transition-all flex items-center justify-center gap-2 disabled:bg-slate-800 disabled:text-slate-500 disabled:cursor-not-allowed shadow-lg shadow-indigo-600/10"
            >
              {encryptLoading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Шифрование...
                </>
              ) : (
                <>
                  <Shield className="w-4 h-4" />
                  Зашифровать текст
                </>
              )}
            </button>
            <button
              onClick={clearEncrypt}
              className="px-3 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl transition-colors border border-slate-700/50"
              title="Очистить"
            >
              <RefreshCw className="w-4 h-4" />
            </button>
          </div>

          {encryptError && (
            <div className="p-3 bg-red-500/10 border border-red-500/20 rounded-xl text-xs text-red-400 font-mono">
              ❌ Ошибка: {encryptError}
            </div>
          )}

          {encryptOutput && (
            <div className="space-y-4 pt-4 border-t border-slate-800 flex-1">
              <div>
                <div className="flex items-center justify-between text-xs font-semibold text-slate-400 mb-1 uppercase tracking-wider">
                  <span>Текст-Режим (Шифр)</span>
                  <button 
                    onClick={() => triggerCopy(encryptOutput.encryptedText, "cipher")}
                    className="flex items-center gap-1 text-indigo-400 hover:text-indigo-300 transition-colors text-[10px]"
                  >
                    {copiedKey === "cipher" ? (
                      <>
                        <Check className="w-3 h-3 text-emerald-400" /> Скопировано
                      </>
                    ) : (
                      <>
                        <Copy className="w-3 h-3" /> Копировать
                      </>
                    )}
                  </button>
                </div>
                <div className="p-3 bg-slate-950 border border-slate-800/80 rounded-xl text-sm font-mono text-indigo-300 break-all select-all">
                  {encryptOutput.encryptedText}
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between text-xs font-semibold text-slate-400 mb-1 uppercase tracking-wider">
                  <span>Вокал-Режим (Фонетика)</span>
                  <button 
                    onClick={() => triggerCopy(encryptOutput.phoneticText, "phone")}
                    className="flex items-center gap-1 text-indigo-400 hover:text-indigo-300 transition-colors text-[10px]"
                  >
                    {copiedKey === "phone" ? (
                      <>
                        <Check className="w-3 h-3 text-emerald-400" /> Скопировано
                      </>
                    ) : (
                      <>
                        <Copy className="w-3 h-3" /> Копировать
                      </>
                    )}
                  </button>
                </div>
                <div className="p-3 bg-slate-950 border border-slate-800/80 rounded-xl text-sm italic text-amber-300 font-serif">
                  {encryptOutput.phoneticText}
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between text-xs font-semibold text-slate-400 mb-1 uppercase tracking-wider">
                  <span>Временной квантовый ключ (TQB-Key)</span>
                  <button 
                    onClick={() => triggerCopy(encryptOutput.decryptionCode, "key")}
                    className="flex items-center gap-1 text-indigo-400 hover:text-indigo-300 transition-colors text-[10px]"
                  >
                    {copiedKey === "key" ? (
                      <>
                        <Check className="w-3 h-3 text-emerald-400" /> Скопировано
                      </>
                    ) : (
                      <>
                        <Copy className="w-3 h-3" /> Копировать
                      </>
                    )}
                  </button>
                </div>
                <div className="p-3 bg-slate-950 border border-slate-800/80 rounded-xl text-sm font-mono text-cyan-300 select-all">
                  {encryptOutput.decryptionCode}
                </div>
              </div>

              <div className="p-3 bg-slate-950/40 border border-slate-800/60 rounded-xl space-y-2">
                <h4 className="text-xs font-semibold text-slate-300 flex items-center gap-1.5 border-b border-slate-800 pb-1.5">
                  <ArrowRightLeft className="w-3.5 h-3.5 text-indigo-400" />
                  Семантическая расшифровка моста
                </h4>
                <div className="space-y-2 max-h-40 overflow-y-auto pr-1.5 scrollbar-thin">
                  {encryptOutput.explanation.map((exp, idx) => (
                    <div key={idx} className="text-xs space-y-0.5 border-b border-slate-800/40 last:border-0 pb-1.5 last:pb-0">
                      <div className="flex justify-between font-semibold text-slate-200">
                        <span>"{exp.originalWord}"</span>
                        <span className="text-cyan-400 text-[10px] font-mono">{exp.rootLanguage}</span>
                      </div>
                      <p className="text-slate-400 text-[11px]">
                        Роль: <span className="text-slate-300">{exp.semanticPrimitive}</span> • Корень: <span className="text-slate-300">{exp.rootWord}</span>
                      </p>
                      <p className="text-indigo-400 text-[10px] font-mono">
                        Блок: {exp.formula}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Decryption Module */}
      <div className="bg-slate-900/60 p-6 rounded-2xl border border-slate-800 backdrop-blur-xl flex flex-col shadow-xl">
        <div className="flex items-center gap-2 mb-4">
          <div className="w-8 h-8 rounded-lg bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center text-cyan-400">
            <Key className="w-4 h-4" />
          </div>
          <div>
            <h3 className="font-semibold text-slate-100 text-base">Квантовая дешифровка (Apeiron-4579)</h3>
            <p className="text-xs text-slate-400">Развертка зашифрованного shell-кода в открытый текст</p>
          </div>
        </div>

        <div className="space-y-4 flex-1 flex flex-col">
          <div>
            <label className="block text-xs font-semibold text-slate-400 mb-1.5 uppercase tracking-wider">Зашифрованный текст (Text-Mode)</label>
            <textarea
              placeholder="Вставьте зашифрованный код Apeiron-4579..."
              value={cipherInput}
              onChange={(e) => setCipherInput(e.target.value)}
              className="w-full h-24 bg-slate-950 border border-slate-800 focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 rounded-xl p-3 text-sm focus:outline-none text-slate-200 font-mono placeholder:text-slate-600 placeholder:font-sans transition-all resize-none"
              disabled={decryptLoading}
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-400 mb-1.5 uppercase tracking-wider">Квантовый TQB-Ключ</label>
            <div className="flex items-center gap-2 bg-slate-950 border border-slate-800 px-3 py-2 rounded-xl focus-within:border-cyan-500 transition-all">
              <Key className="w-4 h-4 text-cyan-400 shrink-0" />
              <input
                type="text"
                placeholder="Ключ дешифровки (TQB-4579-...)"
                value={decryptionKey}
                onChange={(e) => setDecryptionKey(e.target.value)}
                className="bg-transparent text-sm text-slate-200 focus:outline-none w-full font-mono placeholder:text-slate-600 placeholder:font-sans"
                disabled={decryptLoading}
              />
            </div>
          </div>

          <div className="flex gap-2">
            <button
              onClick={handleDecrypt}
              disabled={decryptLoading || !cipherInput.trim() || !decryptionKey.trim()}
              className="flex-1 bg-cyan-600 hover:bg-cyan-500 text-white font-semibold py-2.5 rounded-xl transition-all flex items-center justify-center gap-2 disabled:bg-slate-800 disabled:text-slate-500 disabled:cursor-not-allowed shadow-lg shadow-cyan-600/10"
            >
              {decryptLoading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Дешифровка...
                </>
              ) : (
                <>
                  <Key className="w-4 h-4" />
                  Расшифровать текст
                </>
              )}
            </button>
            <button
              onClick={clearDecrypt}
              className="px-3 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl transition-colors border border-slate-700/50"
              title="Очистить"
            >
              <RefreshCw className="w-4 h-4" />
            </button>
          </div>

          {decryptError && (
            <div className="p-3 bg-red-500/10 border border-red-500/20 rounded-xl text-xs text-red-400 font-mono">
              ❌ Ошибка: {decryptError}
            </div>
          )}

          {decryptOutput && (
            <div className="space-y-4 pt-4 border-t border-slate-800 flex-1">
              <div>
                <div className="flex items-center justify-between text-xs font-semibold text-slate-400 mb-1 uppercase tracking-wider">
                  <span>Расшифрованный текст</span>
                  <button 
                    onClick={() => triggerCopy(decryptOutput.decryptedText, "decrypted")}
                    className="flex items-center gap-1 text-cyan-400 hover:text-cyan-300 transition-colors text-[10px]"
                  >
                    {copiedKey === "decrypted" ? (
                      <>
                        <Check className="w-3 h-3 text-emerald-400" /> Скопировано
                      </>
                    ) : (
                      <>
                        <Copy className="w-3 h-3" /> Копировать
                      </>
                    )}
                  </button>
                </div>
                <div className="p-4 bg-slate-950 border border-slate-800/80 rounded-xl text-base text-slate-100 select-all">
                  {decryptOutput.decryptedText}
                </div>
              </div>

              <div className="p-3 bg-slate-950/40 border border-slate-800/60 rounded-xl space-y-2.5">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                    <Shield className="w-3.5 h-3.5 text-cyan-400" />
                    Квантовая стабильность дешифровки
                  </h4>
                  <span className={`text-xs font-mono font-bold ${
                    decryptOutput.confidence > 0.8 ? "text-emerald-400" : "text-amber-400"
                  }`}>
                    {Math.round(decryptOutput.confidence * 100)}%
                  </span>
                </div>
                
                <div className="w-full bg-slate-950 h-2 rounded-full overflow-hidden border border-slate-800">
                  <div 
                    className={`h-full rounded-full transition-all duration-500 ${
                      decryptOutput.confidence > 0.8 ? "bg-emerald-500" : "bg-amber-500"
                    }`}
                    style={{ width: `${decryptOutput.confidence * 100}%` }}
                  />
                </div>

                <p className="text-xs text-slate-400 leading-relaxed italic border-t border-slate-800/40 pt-2">
                  {decryptOutput.explanation}
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>

    {/* Панель статистического анализа и оценки криптостойкости */}
    <CryptoStatsPanel encryptedText={encryptOutput?.encryptedText || ""} />
  </div>
  );
}
