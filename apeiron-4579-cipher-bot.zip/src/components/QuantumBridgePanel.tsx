import React, { useState, useEffect } from "react";
import { Shield, Cpu, RefreshCw, Layers, Binary, Hourglass, Zap, HelpCircle } from "lucide-react";

export default function QuantumBridgePanel() {
  const [timeHash, setTimeHash] = useState("");
  const [msRemaining, setMsRemaining] = useState(0);
  const [entropy, setEntropy] = useState<number[]>(Array.from({ length: 20 }, () => Math.random() * 100));
  const [fibIndex, setFibIndex] = useState(0);
  const [activeBit, setActiveBit] = useState<number | null>(null);

  // Constants
  const BREMERMANNS_LIMIT = "1.36 × 10^50 bits/s/g";
  const YEAR_4579 = new Date("4579-01-01T00:00:00Z").getTime();

  useEffect(() => {
    // Generate Hour Hash based on current hour
    updateHourHash();

    // Milliseconds remaining until year 4579
    const timer = setInterval(() => {
      const now = Date.now();
      setMsRemaining(YEAR_4579 - now);
    }, 47);

    // Dynamic entropy waveform
    const entropyTimer = setInterval(() => {
      setEntropy((prev) => {
        const next = [...prev.slice(1), Math.max(10, Math.min(100, prev[prev.length - 1] + (Math.random() - 0.5) * 20))];
        return next;
      });
      setFibIndex((prev) => (prev + 1) % 10);
      setActiveBit(Math.floor(Math.random() * 64));
    }, 500);

    return () => {
      clearInterval(timer);
      clearInterval(entropyTimer);
    };
  }, []);

  const updateHourHash = () => {
    const hour = new Date().getHours();
    // Simulate SHA-256 for the hour-hash
    const dummyHash = Array.from({ length: 8 }, (_, idx) => 
      Math.sin(hour + idx).toString(16).substring(3, 7).toUpperCase()
    ).join("-");
    setTimeHash(dummyHash);
  };

  // Format countdown
  const formatCountdown = () => {
    if (msRemaining <= 0) return "TIME-LOCK COLLAPSED";
    const years = Math.floor(msRemaining / (365.25 * 24 * 60 * 60 * 1000));
    const days = Math.floor((msRemaining % (365.25 * 24 * 60 * 60 * 1000)) / (24 * 60 * 60 * 1000));
    const hours = Math.floor((msRemaining % (24 * 60 * 60 * 1000)) / (60 * 60 * 1000));
    const minutes = Math.floor((msRemaining % (60 * 60 * 1000)) / (60 * 1000));
    const seconds = Math.floor((msRemaining % (60 * 1000)) / 1000);
    const ms = Math.floor(msRemaining % 1000);

    return {
      years,
      days,
      hours,
      minutes,
      seconds,
      ms
    };
  };

  const countdown = formatCountdown();
  const fibonacci = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55];

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
      {/* 4579 Countdown & Time Lock */}
      <div className="lg:col-span-2 bg-slate-900/60 p-6 rounded-2xl border border-slate-800 backdrop-blur-xl shadow-xl space-y-6">
        <div className="flex items-center gap-2.5 border-b border-slate-800 pb-4">
          <div className="w-9 h-9 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400">
            <Hourglass className="w-4.5 h-4.5 animate-spin" style={{ animationDuration: "12s" }} />
          </div>
          <div>
            <h3 className="font-semibold text-slate-100 text-sm">4579 Хроно-Блокировка (Chrono Time-Lock)</h3>
            <p className="text-xs text-slate-400">Временная экспонента дешифрации до точки сингулярности</p>
          </div>
        </div>

        {/* Big Countdown Timer */}
        {typeof countdown === "object" && (
          <div className="bg-slate-950/80 p-6 rounded-2xl border border-slate-800 flex justify-around items-center gap-4 text-center">
            <div className="space-y-1">
              <span className="text-3xl md:text-5xl font-mono font-bold text-slate-100 glow-amber">{countdown.years}</span>
              <p className="text-[10px] text-slate-500 uppercase tracking-widest font-semibold">Лет</p>
            </div>
            <span className="text-2xl font-mono text-slate-700 animate-pulse">:</span>
            <div className="space-y-1">
              <span className="text-3xl md:text-5xl font-mono font-bold text-slate-300">{countdown.days}</span>
              <p className="text-[10px] text-slate-500 uppercase tracking-widest font-semibold">Дней</p>
            </div>
            <span className="text-2xl font-mono text-slate-700 animate-pulse">:</span>
            <div className="space-y-1">
              <span className="text-3xl md:text-5xl font-mono font-bold text-slate-300">{countdown.hours.toString().padStart(2, "0")}</span>
              <p className="text-[10px] text-slate-500 uppercase tracking-widest font-semibold">Часов</p>
            </div>
            <span className="text-2xl font-mono text-slate-700 animate-pulse">:</span>
            <div className="space-y-1">
              <span className="text-3xl md:text-5xl font-mono font-bold text-slate-300">{countdown.minutes.toString().padStart(2, "0")}</span>
              <p className="text-[10px] text-slate-500 uppercase tracking-widest font-semibold">Мин</p>
            </div>
            <span className="text-2xl font-mono text-slate-700 animate-pulse">:</span>
            <div className="space-y-1">
              <span className="text-2xl md:text-4xl font-mono font-bold text-indigo-400">{countdown.seconds.toString().padStart(2, "0")}</span>
              <p className="text-[10px] text-slate-500 uppercase tracking-widest font-semibold">Сек</p>
            </div>
            <span className="text-xl font-mono text-slate-700 animate-pulse">.</span>
            <div className="space-y-1 w-14">
              <span className="text-lg md:text-2xl font-mono font-medium text-indigo-500">{countdown.ms.toString().padStart(3, "0")}</span>
              <p className="text-[9px] text-slate-500 uppercase tracking-widest font-semibold">Мс</p>
            </div>
          </div>
        )}

        {/* Chronological details */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs leading-relaxed">
          <div className="bg-slate-950/40 p-4 rounded-xl border border-slate-800/60 space-y-2">
            <h4 className="font-bold text-slate-200 flex items-center gap-1.5">
              <Cpu className="w-3.5 h-3.5 text-indigo-400" /> Предел Бремерманна
            </h4>
            <p className="text-slate-400">
              Вычислительный предел квантового вещества составляет <span className="text-slate-300 font-bold">{BREMERMANNS_LIMIT}</span>. 
              Согласно VDF-формуле Apeiron-4579, параллельные вычисления невозможны. 
              Последовательный просчет ключа требует непрерывной работы одного ядра в течение ровно 2 553 лет.
            </p>
          </div>

          <div className="bg-slate-950/40 p-4 rounded-xl border border-slate-800/60 space-y-2">
            <h4 className="font-bold text-slate-200 flex items-center gap-1.5">
              <Zap className="w-3.5 h-3.5 text-cyan-400" /> Квантовый Мост (TQB)
            </h4>
            <p className="text-slate-400">
              Временный Квантовый Мост (Temporary Quantum Bridge) создает локальный коридор дешифрования. 
              Он основан на хеше текущего часа и Fibonacci-прогрессии. Ключ уничтожается при закрытии сессии. 
              Любой перехватчик получает бесполезный бинарный шум до 4579 года.
            </p>
          </div>
        </div>
      </div>

      {/* TQB Configuration & Waveform */}
      <div className="bg-slate-900/60 p-6 rounded-2xl border border-slate-800 backdrop-blur-xl shadow-xl space-y-5">
        <div className="flex items-center gap-2.5 border-b border-slate-800 pb-4">
          <div className="w-9 h-9 rounded-xl bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center text-cyan-400">
            <Binary className="w-4.5 h-4.5" />
          </div>
          <div>
            <h3 className="font-semibold text-slate-100 text-sm">Спектр Сопряжения Моста</h3>
            <p className="text-xs text-slate-400">Текущий индекс энтропии TQB-канала</p>
          </div>
        </div>

        {/* Hour Hash Block */}
        <div className="space-y-1.5">
          <div className="flex justify-between items-center text-xs">
            <span className="text-slate-400 uppercase tracking-widest font-semibold">Hour-Hash (Базовое Смещение)</span>
            <button onClick={updateHourHash} className="text-cyan-400 hover:text-cyan-300 transition-colors">
              <RefreshCw className="w-3 h-3" />
            </button>
          </div>
          <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl text-center text-xs font-mono text-cyan-400 font-bold select-all">
            {timeHash || "CALIBRATING-HASH-LINK"}
          </div>
        </div>

        {/* Fibonacci Sequence Alignment */}
        <div className="space-y-2">
          <span className="text-xs text-slate-400 uppercase tracking-widest font-semibold block">Фибоначчи Дешифрация (Шаги)</span>
          <div className="flex items-center gap-1 text-xs justify-between overflow-x-auto p-1 bg-slate-950 rounded-lg border border-slate-900 scrollbar-none">
            {fibonacci.map((val, idx) => (
              <span 
                key={idx} 
                className={`w-7 h-7 rounded flex items-center justify-center font-mono text-[10px] border ${
                  fibIndex === idx 
                    ? "bg-indigo-600/20 border-indigo-500 text-indigo-300 font-bold scale-110" 
                    : "bg-slate-900/40 border-slate-800 text-slate-500"
                }`}
              >
                {val}
              </span>
            ))}
          </div>
        </div>

        {/* Reactive Entropy Waveform (SVG) */}
        <div className="space-y-2">
          <div className="flex justify-between text-xs text-slate-500">
            <span>Стабильность TQB-моста</span>
            <span className="text-emerald-400 font-mono">Сопряжено</span>
          </div>
          <div className="h-16 bg-slate-950/80 rounded-xl border border-slate-800 flex items-end p-2 overflow-hidden relative">
            {/* Background binary noise */}
            <div className="absolute inset-0 grid grid-cols-8 gap-1 p-2 text-[8px] text-indigo-950/30 font-mono select-none overflow-hidden">
              {Array.from({ length: 32 }).map((_, idx) => (
                <span key={idx} className={activeBit === idx ? "text-indigo-400/10" : ""}>
                  {idx % 2 === 0 ? "1" : "0"}
                </span>
              ))}
            </div>

            {/* Custom SVG Sparkline */}
            <svg className="w-full h-full relative z-10" viewBox="0 0 100 30" preserveAspectRatio="none">
              <defs>
                <linearGradient id="g" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#4f46e5" stopOpacity="0.4" />
                  <stop offset="100%" stopColor="#4f46e5" stopOpacity="0" />
                </linearGradient>
              </defs>
              <path
                d={`M 0 ${30 - (entropy[0] / 100) * 25} ` + entropy.map((val, idx) => `L ${(idx / (entropy.length - 1)) * 100} ${30 - (val / 100) * 25}`).join(" ")}
                fill="none"
                stroke="#6366f1"
                strokeWidth="1.5"
                strokeLinecap="round"
              />
              <path
                d={`M 0 ${30 - (entropy[0] / 100) * 25} ` + entropy.map((val, idx) => `L ${(idx / (entropy.length - 1)) * 100} ${30 - (val / 100) * 25}`).join(" ") + ` L 100 30 L 0 30 Z`}
                fill="url(#g)"
              />
            </svg>
          </div>
        </div>
      </div>
    </div>
  );
}
