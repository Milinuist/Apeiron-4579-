import React, { useState } from "react";
import { MessageSquare, Shield, HelpCircle, Cpu, Terminal, Sparkles, AlertCircle } from "lucide-react";
import ChatSimulator from "./components/ChatSimulator.tsx";
import DirectConverter from "./components/DirectConverter.tsx";
import QuantumBridgePanel from "./components/QuantumBridgePanel.tsx";
import TelegramConfig from "./components/TelegramConfig.tsx";

export default function App() {
  const [activeTab, setActiveTab] = useState<"chat" | "converter" | "bridge" | "telegram">("chat");
  const [showDocModal, setShowDocModal] = useState(false);

  return (
    <div className="min-h-screen bg-[#020617] text-slate-100 font-sans relative overflow-x-hidden selection:bg-indigo-500/30 selection:text-indigo-200">
      {/* Background visual graphics */}
      <div className="absolute top-0 left-1/4 w-[500px] h-[500px] bg-indigo-500/5 rounded-full blur-[120px] pointer-events-none"></div>
      <div className="absolute bottom-1/4 right-1/4 w-[400px] h-[400px] bg-cyan-500/5 rounded-full blur-[100px] pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 relative z-10 flex flex-col min-h-screen">
        {/* Navigation / Header Header */}
        <header className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900/40 p-5 rounded-2xl border border-slate-800/80 backdrop-blur-md mb-8">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-indigo-600/15 border border-indigo-500/30 flex items-center justify-center text-indigo-400 font-bold shadow-lg shadow-indigo-500/5">
              <span className="text-xl">Ω</span>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl font-bold tracking-tight text-slate-100">Apeiron-4579</h1>
                <span className="text-[10px] bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 px-1.5 py-0.5 rounded font-mono font-bold tracking-widest">v1.2</span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">Crypto-Linguistic Engine & Telegram Bot Hub</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => setShowDocModal(true)}
              className="flex items-center gap-2 text-xs text-slate-300 hover:text-indigo-400 bg-slate-800/40 hover:bg-slate-800 border border-slate-700/50 px-3.5 py-2 rounded-xl transition-all font-medium"
            >
              <HelpCircle className="w-4 h-4" />
              Документация шифра
            </button>
          </div>
        </header>

        {/* Tab Selector Nav Row */}
        <div className="flex items-center overflow-x-auto gap-2 bg-slate-950/80 border border-slate-850/80 p-1.5 rounded-2xl mb-8 scrollbar-none">
          <button
            onClick={() => setActiveTab("chat")}
            className={`px-4 py-3 rounded-xl text-xs sm:text-sm font-semibold transition-all flex items-center gap-2 shrink-0 ${
              activeTab === "chat"
                ? "bg-indigo-600 text-white shadow-lg shadow-indigo-600/15"
                : "text-slate-400 hover:text-slate-200 hover:bg-slate-900/40"
            }`}
          >
            <MessageSquare className="w-4 h-4" />
            Симулятор бота
          </button>
          <button
            onClick={() => setActiveTab("converter")}
            className={`px-4 py-3 rounded-xl text-xs sm:text-sm font-semibold transition-all flex items-center gap-2 shrink-0 ${
              activeTab === "converter"
                ? "bg-indigo-600 text-white shadow-lg shadow-indigo-600/15"
                : "text-slate-400 hover:text-slate-200 hover:bg-slate-900/40"
            }`}
          >
            <Shield className="w-4 h-4" />
            Прямой конвертер
          </button>
          <button
            onClick={() => setActiveTab("bridge")}
            className={`px-4 py-3 rounded-xl text-xs sm:text-sm font-semibold transition-all flex items-center gap-2 shrink-0 ${
              activeTab === "bridge"
                ? "bg-indigo-600 text-white shadow-lg shadow-indigo-600/15"
                : "text-slate-400 hover:text-slate-200 hover:bg-slate-900/40"
            }`}
          >
            <Cpu className="w-4 h-4" />
            Квантовый Мост (TQB)
          </button>
          <button
            onClick={() => setActiveTab("telegram")}
            className={`px-4 py-3 rounded-xl text-xs sm:text-sm font-semibold transition-all flex items-center gap-2 shrink-0 ${
              activeTab === "telegram"
                ? "bg-indigo-600 text-white shadow-lg shadow-indigo-600/15"
                : "text-slate-400 hover:text-slate-200 hover:bg-slate-900/40"
            }`}
          >
            <Terminal className="w-4 h-4" />
            Настоящий Telegram Бот
          </button>
        </div>

        {/* Dynamic Tab Body Content */}
        <main className="flex-1">
          {activeTab === "chat" && <ChatSimulator />}
          {activeTab === "converter" && <DirectConverter />}
          {activeTab === "bridge" && <QuantumBridgePanel />}
          {activeTab === "telegram" && <TelegramConfig />}
        </main>

        {/* Aesthetic footer */}
        <footer className="mt-16 pt-6 border-t border-slate-900 text-center text-[11px] text-slate-500 font-mono tracking-wider flex flex-col md:flex-row justify-between items-center gap-3">
          <p>© 2026-4579 Apeiron-4579 Project. All logs securely hashed with Hour-VDF protocol.</p>
          <div className="flex gap-4">
            <span className="text-slate-600 hover:text-indigo-400 transition-colors">Bremermann's Computing Guard</span>
            <span>•</span>
            <span className="text-slate-600 hover:text-cyan-400 transition-colors">Quantum Bridge Coherence: Active</span>
          </div>
        </footer>
      </div>

      {/* Technical Documentation Modal */}
      {showDocModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md transition-all">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-2xl max-h-[85vh] overflow-y-auto shadow-2xl p-6 relative">
            <button
              onClick={() => setShowDocModal(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-slate-200 font-bold text-lg px-2.5 py-1 hover:bg-slate-800 rounded-lg transition-colors"
            >
              ×
            </button>
            
            <div className="space-y-6">
              <div className="border-b border-slate-800 pb-3 flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-indigo-400 animate-pulse" />
                <h2 className="text-lg font-bold text-slate-100">Спецификация Шифра Apeiron-4579</h2>
              </div>

              <div className="space-y-4 text-sm text-slate-300 leading-relaxed">
                <div>
                  <h4 className="font-bold text-slate-200 mb-1 flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 bg-indigo-500 rounded-full"></span>
                    1. Фундаментальный концепт (Time-Lock)
                  </h4>
                  <p className="text-xs text-slate-400 pl-4">
                    "Apeiron-4579" — это динамический процесс. Ядро криптографии опирается на последовательную функцию задержки (VDF). 
                    Расчет ключа дешифрования на максимальной теоретической мощности (предел Бремерманна) занимает ровно 2553 года. 
                    Любой перехваченный сессионный пакет закрыт до 4579 года.
                  </p>
                </div>

                <div>
                  <h4 className="font-bold text-slate-200 mb-1 flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 bg-indigo-500 rounded-full"></span>
                    2. Лингвистическое морфирование (Omnilingual)
                  </h4>
                  <p className="text-xs text-slate-400 pl-4">
                    Язык не имеет статичного словаря. Он использует семантические примитивы (базовые смыслы, например "Огонь", "Я", "Движение"), 
                    которые динамически заворачиваются в случайные корни из всех 7000+ земных языков в зависимости от миллисекунды генерации.
                    <br />
                    <span className="font-semibold text-slate-300">Формула слова:</span> <code className="text-indigo-400 font-mono text-[10px] bg-slate-950 px-1 py-0.5 rounded">[Cipher-Prefix] + [Random Root] + [Timestamp-Suffix]</code>.
                  </p>
                </div>

                <div>
                  <h4 className="font-bold text-slate-200 mb-1 flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 bg-indigo-500 rounded-full"></span>
                    3. Режимы связи
                  </h4>
                  <p className="text-xs text-slate-400 pl-4 space-y-1">
                    <span>• <strong className="text-slate-300">Text-Mode:</strong> Символы разных алфавитов (латиница, кириллица, кандзи, арабская вязь) переплетаются с математическими операторами по ряду Фибоначчи.</span>
                    <br />
                    <span>• <strong className="text-slate-300">Voice-Mode:</strong> Для голосового произношения шифр конвертируется в тональные слоги со строгой структурой C-V (согласный-гласный), 4 тональными высотами и ритмической паузой. Напоминает мантру.</span>
                  </p>
                </div>

                <div>
                  <h4 className="font-bold text-slate-200 mb-1 flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 bg-indigo-500 rounded-full"></span>
                    4. Handshake-Протокол
                  </h4>
                  <p className="text-xs text-slate-400 pl-4">
                    Для активации криптографической сессии ИИ должен получить строгое кодовое выражение: 
                    <br />
                    <code className="text-cyan-400 font-mono text-[11px] bg-slate-950 px-1.5 py-0.5 rounded block mt-1.5 text-center">INITIATE: APEIRON-4579 [Sync-Lock: Active]</code>
                  </p>
                </div>
              </div>

              <div className="pt-4 border-t border-slate-800 flex justify-end">
                <button
                  onClick={() => setShowDocModal(false)}
                  className="bg-indigo-600 hover:bg-indigo-500 text-white font-bold px-5 py-2 rounded-xl text-xs transition-colors"
                >
                  Принять регламент безопасности
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
