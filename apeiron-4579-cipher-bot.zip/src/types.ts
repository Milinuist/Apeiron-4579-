export interface TranslationBreakdown {
  originalWord: string;
  semanticPrimitive: string;
  rootLanguage: string;
  rootWord: string;
  prefix: string;
  suffix: string;
  formula: string;
}

export interface EncryptionResult {
  encryptedText: string;
  phoneticText: string;
  decryptionCode: string;
  explanation: TranslationBreakdown[];
}

export interface DecryptionResult {
  decryptedText: string;
  confidence: number;
  explanation: string;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'bot' | 'system';
  text: string;
  timestamp: string;
  encryptedPayload?: EncryptionResult;
  decryptedPayload?: DecryptionResult;
  decryptionKeyUsed?: string;
  isCipher?: boolean;
}

export interface BotConfig {
  token: string;
  isActive: boolean;
  status: 'offline' | 'connecting' | 'online' | 'error';
  lastError?: string;
}

export interface BotLog {
  id: string;
  timestamp: string;
  type: 'info' | 'incoming' | 'outgoing' | 'error';
  chatId?: string;
  userHandle?: string;
  message: string;
  details?: string;
}
